document.addEventListener("DOMContentLoaded", function () {
    let flage = false
    for (let i = 1; i <= 5; i++) {
        document.getElementById(`m${i}`).addEventListener("mouseover", function () { mouseOver(i) });
        document.getElementById(`m${i}`).addEventListener("mouseout", mouseOut);
        document.getElementById(`m${i}`).addEventListener("click", function () { click(i) });
        document.getElementById(`m${i}`).addEventListener("dblclick",dblclick)
    }

    function mouseOver(num) {
        //動態樣式改變，方法 1
        // document.getElementById("h").style.color="red"
        //動態樣式改變，方法 2
        if (flage == false) {
            document.getElementById(`m${num}`).className = "s";
            for (let j = 1; j < num; j++) {
                document.getElementById(`m${j}`).className = "s";
            }
            document.getElementById("p1").innerHTML=`評分為${num}`
        }
        // this.className = "s"
    }

    function mouseOut() {
        //動態樣式改變，方法 1
        // document.getElementById("h").style.color="red"
        //動態樣式改變，方法 2
        // document.getElementById("h").className="n"
        // this.className = "n"
        if (flage == false) {
            for (let j = 1; j <= 5; j++) {
                document.getElementById(`m${j}`).className = "n";
            }
            document.getElementById("p1").innerHTML=`評分為0`
        }
    }
    function click(num) {
        if(flage==false){
        document.getElementById(`m${num}`).className = "s";
        for (let j = 1; j < num; j++) {
            document.getElementById(`m${j}`).className = "s";
        }
        document.getElementById("p1").innerHTML=`評分為${num}`
        flage = true;
        }
    }
    function dblclick(){
        flage = false;
        if (flage == false) {
            for (let j = 1; j <= 5; j++) {
                document.getElementById(`m${j}`).className = "n";
            }
            document.getElementById("p1").innerHTML=`評分為0`
        }
    }

});
