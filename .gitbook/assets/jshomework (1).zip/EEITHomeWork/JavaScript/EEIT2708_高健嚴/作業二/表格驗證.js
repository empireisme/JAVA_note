function checkusrn() { 
    var check = false; 
    var username = document.getElementById("name").value;    
    var check = false;
    if (username == "" || username.length<2) {
        document.getElementById("sp1").innerHTML = " <img src='images/error.png' > 不可以空白";
        document.getElementById("sp1").style.color="red"
    }
    if (username.length<2) {
        document.getElementById("sp1").innerHTML = "<img src='images/error.png' >最少需要兩個字 ";
        document.getElementById("sp1").style.color="red"
    }else{
    for (i = 0; i < username.length; i++) {
        let ch = username.charCodeAt(i);
        console.log(ch)
        if (ch >= 0x4e00 && ch <= 0x9fff) {
            check = true
            document.getElementById("sp1").innerHTML = " √";
        } else {
            check = false
            document.getElementById("sp1").innerHTML = "<img src='images/error.png' >請輸入中文字元";
            document.getElementById("sp1").style.color="red"
            break
        }
    }}
    return check;
}

    
    function checkpwd() { 
        var check = false;
        var password = document.getElementById("pwd").value;
        let flag1 = false, flag2 = false, flag3 = false;
        if (password == "" || password.length < 6) {
            document.getElementById("sp2").innerHTML = "<img src='images/error.png' > 不要少於6位";
            document.getElementById("sp2").style.color="red"
            check = false;
        } else if (password.length >= 6) {
            for (let i = 0; i < password.length; i++) {
                let ch = password.charAt(i).toUpperCase();
                if (ch >= "A" && ch <= "Z")
                    flag1 = true
                if (flag1) break
            }
            if (flag1){
                document.getElementById("sp2").innerHTML = "√輸入正確"
                document.getElementById("sp2").style.color="green"
            }else{
                document.getElementById("sp2").innerHTML = "<img src='images/error.png' >至少輸入一個英文字"
                document.getElementById("sp2").style.color="red"}

        } else {
            document.getElementById("sp2").innerHTML = " √";
            check = true;
        }
        return check; 
    } 

    var validateDate = function (originalYear, originalMonth, originalDay) {
        var date = new Date(originalYear, originalMonth - 1, originalDay);
        var year = date.getFullYear();
        var month = date.getMonth()+1;
        var day = date.getDate();
        return year == originalYear && month == originalMonth && day == originalDay;
        } 

    function chdate(){
        var check = false;
        var date = document.getElementById("date").value;
        let d =new Date(`${date}`)
        var MM = (d.getMonth()+1<10 ? '0' : '')+(d.getMonth()+1);
        var dd = (d.getDate()<10 ? '0' : '')+d.getDate();
        var h=d.getFullYear()+"-"+MM+"-"+dd

        
        if(h==date){
            document.getElementById("sp3").innerHTML = "√輸入正確"
            document.getElementById("sp3").style.color="green"
        }else{
            document.getElementById("sp3").innerHTML = "<img src='images/error.png' >日期錯誤"
            document.getElementById("sp3").style.color="red"}
        

    }
 
    function check() { 
    var check = checkusrn() && checkpwd() && checkpwdc() && checkcb(); 
    return check; 
    } 