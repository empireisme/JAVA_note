document.addEventListener("DOMContentLoaded",function(){
    let img=0;
    let t;
    let flage=true;
    function f(){
        if(flage){
            img++
            if(img>4)img=1;
            if(img<1)img=4;
             document.getElementById("m1").src="images/羅技"+img+".jpg"
             document.getElementById("f2").innerHTML= `${img}`
        }   
    }

    function stopvin(){
        window.clearTimeout(t)
        document.getElementById("f1").style.border = "5px solid blue";
        document.getElementById("f1").style.boxShadow= "5px 5px 5px gray"
    }

    function starvin(){
        t=  window.setInterval(f,2000)
        document.getElementById("f1").style.border = "5px solid rgb(0, 140, 255)";
        document.getElementById("f1").style.boxShadow= "0px 0px 0px gray"
    }

    function strstop(){
        if(flage){
            window.clearTimeout(t)
            document.getElementById("f1").style.border = "5px solid blue";
            document.getElementById("f1").style.boxShadow= "5px 5px 5px gray"
            flage=false
            return flage
        }else{
            t=  window.setInterval(f,2000)
            document.getElementById("f1").style.border = "5px solid rgb(0, 140, 255)";
            document.getElementById("f1").style.boxShadow= "0px 0px 0px gray"
            flage=true
            return flage
        }
    }

    function reimg(){
        
        flage=true
        img+=-2
        window.clearTimeout(t)
        f();
        t = window.setInterval(f,2000)
        document.getElementById("f1").style.border = "5px solid rgb(0, 140, 255)";
        document.getElementById("f1").style.boxShadow= "0px 0px 0px gray"
            return flage
    }

    function nextimg(){
        flage=true
        window.clearTimeout(t)
        f();
        t = window.setInterval(f,2000)
        document.getElementById("f1").style.border = "5px solid rgb(0, 140, 255)";
        document.getElementById("f1").style.boxShadow= "0px 0px 0px gray"
            return flage
    }

    function such(m){
        window.clearTimeout(t)
        document.getElementById(`m${m}`).style.boxShadow= "5px 5px 5px gray"
        document.getElementById("m1").src="images/羅技"+(m-1)+".jpg"
        document.getElementById("f2").innerHTML= `${m-1}`
        img=(m-1)
        flage=false
            return flage
        
    }

    function outsuch(m){
        img=m-1
        t=  window.setInterval(f,2000)
        document.getElementById(`m${m}`).style.boxShadow= "0px 0px 0px gray"
        flage=true
            return flage
        
    }

    function hr(){
        if(img==1){
            document.getElementById("hr").href="https://www.logitechg.com/zh-tw"
        }else if(img==2){
            document.getElementById("hr").href="https://www.logitechg.com/zh-tw/products/pro.html"
        }else if(img==3){
            document.getElementById("hr").href="https://www.logitechg.com/zh-tw/playyourway.html"
        }else if(img==4){
            document.getElementById("hr").href="https://www.logitechg.com/zh-tw/products/gaming-audio/g733-rgb-wireless-headset.981-000868.html"
        }
    }

    f();
    t = window.setInterval(f,2000)

    document.getElementById("m1").addEventListener("mousemove",stopvin)
    document.getElementById("m1").addEventListener("mouseout",starvin)

    for(let m=2;m<=5;m++){
        document.getElementById("m"+m).addEventListener("mousemove",function(){ such(m)})
        document.getElementById("m"+m).addEventListener("mouseout",function(){ outsuch(m)})
    }


    
    document.getElementById("hr").addEventListener("click",hr)
    document.getElementById("sp").addEventListener("click",strstop)
    document.getElementById("re").addEventListener("click",reimg)
    document.getElementById("next").addEventListener("click",nextimg)




















})