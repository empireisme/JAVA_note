document.write("<tr>")
for (var i = 2; i <= 9; i++) {
    document.write("<td>");
    for (var j = 1; j <= 9; j++) {
        document.write(`${i}x${j}=${j * i}<br>`);
    }
    document.write("</td>");
}
document.write("</tr>");