for (let i = 2; i < 10; i++) {
    for (let j = 1; j < 10; j++) {
        document.getElementById(i).innerHTML += i + "*" + j + "=" + i * j + "<br>"
    }
}