document.getElementById("account").addEventListener("blur", checkNam);
document.getElementById("idPwd").addEventListener("blur", checkPwd);
document.getElementById("dat").addEventListener("blur", checkDat);

function checkNam() {
    let theAccObj = document.getElementById("account");
    let theAccObjVal = theAccObj.value;
    let theAccObjLen = theAccObjVal.length;
    let spa = document.getElementById("acsp");
    let re4 = /[\u4E00-\u9FFF]/; //是否包含中文字元
    //let re4 = /[\u4e00-\u9fa5]{2,}/; //是否包含中文字元2個以上 

    if (theAccObjVal == "") {
        spa.innerHTML = "<img src='incorrect.jpg'>不能為空";
    } else if (theAccObjLen < 2) {
        spa.innerHTML = "<img src='incorrect.jpg'>至少兩個字";
    } else if (re4.test(theAccObjVal)) {
        spa.innerHTML = "<img src='correct.jpg'>輸入正確";
    } else {
        spa.innerHTML = "<img src='incorrect.jpg'>只能輸入中文字";
    }
}

function checkPwd() {
    let thePwdObj = document.getElementById("idPwd");
    let thePwdObjVal = thePwdObj.value;
    let thePwdObjValLen = thePwdObjVal.length;
    let sp = document.getElementById("idsp");

    let re1 = /[!@#$%^&*]/; //是否包含中括弧中內容
    let re2 = /[A-Za-z]/;
    let re3 = /[0-9]/;
    // let re3 = /([0-9])(.{6,})/; //.代表所有，會判斷輸入的所有字是否至少有6碼
    // let re3 = /[0-9]{6,}/; //會判斷輸入是否含有至少6個0-9

    if (thePwdObjVal == "") {
        sp.innerHTML = "<img src='incorrect.jpg'>不能為空";
    } else if (thePwdObjValLen < 6) {
        sp.innerHTML = "<img src='incorrect.jpg'>至少六個字"
    } else if (re1.test(thePwdObjVal) && re2.test(thePwdObjVal) && re3.test(thePwdObjVal)) {
        sp.innerHTML = "<img src='correct.jpg'>輸入正確"
    } else if (re1.test(thePwdObjVal) && re2.test(thePwdObjVal)) {
        sp.innerHTML = "<img src='incorrect.jpg'>缺少數字"
    } else if (re1.test(thePwdObjVal) && re3.test(thePwdObjVal)) {
        sp.innerHTML = "<img src='incorrect.jpg'>缺少英文"
    } else if (re2.test(thePwdObjVal) && re3.test(thePwdObjVal)) {
        sp.innerHTML = "<img src='incorrect.jpg'>缺少特殊字元"
    } else if (re1.test(thePwdObjVal)) {
        sp.innerHTML = "<img src='incorrect.jpg'>缺少英文、數字"
    } else if (re2.test(thePwdObjVal)) {
        sp.innerHTML = "<img src='incorrect.jpg'>缺少特殊字元、數字"
    } else if (re3.test(thePwdObjVal)) {
        sp.innerHTML = "<img src='incorrect.jpg'>缺少特殊字元、英文"
    } else {
        sp.innerHTML = "<img src='incorrect.jpg'>不符合規則"
    }
}

function checkDat() {
    let theDatObj = document.getElementById("dat");
    let theDatVal = theDatObj.value;
    let theDatLen = theDatObj.length;
    let spd = document.getElementById("dasp");

    //判斷日期格式
    let re5 = /^([0-9]{4})[./]{1}([0-9]{1,2})[./]{1}([0-9]{1,2})$/

    //依/切分輸入的年月日裝進陣列0 1 2
    let dateArray = theDatVal.split("/");
    let year = dateArray[0];
    let month = dateArray[1];
    let day = dateArray[2];

    //年份條件
    let d = new Date();
    let limitYear = year <= d.getFullYear() && year >= (d.getFullYear() - 150);

    //月份條件
    let limitMonth = month >= 1 && month <= 12;

    //日期條件
    let dayArray = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    //閏年條件-西元年能被4整除但不能被100整除，或能被400整除
    let leap = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
    if (leap) {
        dayArray[1] = 29;
    }
    let limitDay = day <= dayArray[month - 1];

    if (theDatVal == "") {
        spd.innerHTML = "<img src='incorrect.jpg'>不能為空";
    } else if (!re5.test(theDatVal)) {
        spd.innerHTML = "<img src='incorrect.jpg'>請輸入 YYYY/MM/DD 日期格式";
    } else if (limitYear && limitMonth && limitDay) {
        spd.innerHTML = "<img src='correct.jpg'>輸入正確";
    } else if (!(limitYear || limitMonth || limitDay)) {
        spd.innerHTML = "<img src='incorrect.jpg'>年月日不在正確範圍";
    } else if (limitYear && limitMonth) {
        spd.innerHTML = "<img src='incorrect.jpg'>輸入日期超出範圍";
    } else if (limitMonth && limitDay) {
        spd.innerHTML = "<img src='incorrect.jpg'>輸入年分超出範圍";
    } else if (limitYear && limitDay) {
        spd.innerHTML = "<img src='incorrect.jpg'>輸入月分超出範圍";
    } else if (limitYear) {
        spd.innerHTML = "<img src='incorrect.jpg'>輸入月份、日期超出範圍";
    } else if (limitMonth) {
        spd.innerHTML = "<img src='incorrect.jpg'>輸入年分、日期超出範圍";
    } else if (limitDay) {
        spd.innerHTML = "<img src='incorrect.jpg'>輸入年分、月份超出範圍";
    } else {
        spd.innerHTML = "<img src='incorrect.jpg'>輸入範圍錯誤";
    }
}