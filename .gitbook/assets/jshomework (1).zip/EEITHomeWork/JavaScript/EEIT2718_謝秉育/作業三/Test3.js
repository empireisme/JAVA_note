document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("idstar1").addEventListener("mouseover", mouseOver1);
    document.getElementById("idstar2").addEventListener("mouseover", mouseOver2);
    document.getElementById("idstar3").addEventListener("mouseover", mouseOver3);
    document.getElementById("idstar4").addEventListener("mouseover", mouseOver4);
    document.getElementById("idstar5").addEventListener("mouseover", mouseOver5);

    let imgs = document.querySelectorAll("img");
    let imgsLen = imgs.length;
    for(let i=0;i<imgsLen;i++) {
        imgs[i].addEventListener("mouseout", mouseOut);
        imgs[i].addEventListener("click", mouseClick);
        imgs[i].addEventListener("dblclick", dblClick);
    }
});

let bool = true;
let str = "";
function mouseOver1() {
    if (bool) {
        document.getElementById("idstar1").className = "n";
        document.getElementById("idstar2").className = "s";
        document.getElementById("idstar3").className = "s";
        document.getElementById("idstar4").className = "s";
        document.getElementById("idstar5").className = "s";
        document.getElementById("figc1").innerHTML = "評分為...1";
        str = "你給1顆星";
    }
}

function mouseOver2() {
    if (bool) {
        document.getElementById("idstar1").className = "n";
        document.getElementById("idstar2").className = "n";
        document.getElementById("idstar3").className = "s";
        document.getElementById("idstar4").className = "s";
        document.getElementById("idstar5").className = "s";
        document.getElementById("figc1").innerHTML = "評分為...2";
        str = "你給2顆星";
    }
}

function mouseOver3() {
    if (bool) {
        document.getElementById("idstar1").className = "n";
        document.getElementById("idstar2").className = "n";
        document.getElementById("idstar3").className = "n";
        document.getElementById("idstar4").className = "s";
        document.getElementById("idstar5").className = "s";
        document.getElementById("figc1").innerHTML = "評分為...3";
        str = "你給3顆星";
    }
}

function mouseOver4() {
    if (bool) {
        document.getElementById("idstar1").className = "n";
        document.getElementById("idstar2").className = "n";
        document.getElementById("idstar3").className = "n";
        document.getElementById("idstar4").className = "n";
        document.getElementById("idstar5").className = "s";
        document.getElementById("figc1").innerHTML = "評分為...4";
        str = "你給4顆星";
    }
}

function mouseOver5() {
    if (bool) {
        document.getElementById("idstar1").className = "n";
        document.getElementById("idstar2").className = "n";
        document.getElementById("idstar3").className = "n";
        document.getElementById("idstar4").className = "n";
        document.getElementById("idstar5").className = "n";
        document.getElementById("figc1").innerHTML = "評分為...5";
        str = "你給5顆星";
    }
}

function mouseOut() {
    if (bool) {
        document.getElementById("idstar1").className = "s";
        document.getElementById("idstar2").className = "s";
        document.getElementById("idstar3").className = "s";
        document.getElementById("idstar4").className = "s";
        document.getElementById("idstar5").className = "s";
        document.getElementById("figc1").innerHTML = "";
    }
}

function mouseClick() {
    document.getElementById("figc1").innerHTML = str
    bool = false;
}

function dblClick() {
    document.getElementById("idstar1").className = "s";
    document.getElementById("idstar2").className = "s";
    document.getElementById("idstar3").className = "s";
    document.getElementById("idstar4").className = "s";
    document.getElementById("idstar5").className = "s";
    document.getElementById("figc1").innerHTML = "";
    bool = true;
}