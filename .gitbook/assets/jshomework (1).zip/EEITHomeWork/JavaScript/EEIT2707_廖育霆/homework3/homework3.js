document.addEventListener("DOMContentLoaded", function () {
    let star1 = document.getElementById("idimg1");
    let star2 = document.getElementById("idimg2");
    let star3 = document.getElementById("idimg3");
    let star4 = document.getElementById("idimg4");
    let star5 = document.getElementById("idimg5");
    let flag = false;

    let starArr = [star1, star2, star3, star4, star5];

    for (let i = 0; i < starArr.length; i++) {
        starArr[i].addEventListener("mousemove", function () {mouseover(i)});
        starArr[i].addEventListener("mouseout", function () {mouseout()});
        starArr[i].addEventListener("click", function () {check(i)});
        starArr[i].addEventListener("dblclick", function () {dbcheck()});
    }

    function mouseover(starnum1) {
        let sp = document.getElementById("score")
        if (flag == false) {
            for (let i = 0; i <= starnum1; i++) {
                starArr[i].src = "Images/chngstar.gif";
                sp.innerHTML = `分數=${ i+1 }`;
                
            }
        }

    }

    function mouseout() {
        let sp = document.getElementById("score")
        if (flag == false) {
            for (let i = 0; i < starArr.length; i++) {
                starArr[i].src = "Images/star.gif";
                sp.innerHTML = `分數=0`;
                
            }
            
        }
    }

    function check(starnum2) {
           if(flag == false){
            for (let i = 0; i <= starnum2; i++) {
                starArr[i].src = "Images/chngstar.gif";
            }
            flag = true;
        }
        
    }

    function dbcheck() {
        let sp = document.getElementById("score")
        for (let i = 0; i < starArr.length; i++) {
            starArr[i].src = "Images/star.gif";
            sp.innerHTML = `分數=0`;
        }
        flag = false;
    }
})
