document.write("<table>")
            
var i=0;
var j=0;
for(i=2;i<=9;i++){
    document.write("<td>")

   for(j=1;j<=9;j++){
    document.write (i+"*"+j+"="+i*j+"<br>");
   }

}
document.write(" </table>")