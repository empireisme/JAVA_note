function checkId() {
    //取得account元素
    let Id = document.getElementById("account1");
    //取得account元素值
    let IdVal = Id.value;
    console.log(IdVal);
    //判斷元素值是否為英文字母，姓名長度是否大於2
    let sp1 = document.getElementById("Spname")
    let IdValLen = IdVal.length;
    let text1 = false

    if (IdValLen == "") {
        sp1.innerHTML = "請輸入姓名";
    } else if (IdValLen >= 2) {
        for (let i = 0; i < IdValLen; i++)
            if (IdVal.charCodeAt(i) < 0x4E00 || IdVal.charCodeAt(i) > 0x9FFF) {
                text1 = true
                if (text1) break;
            }
        if (text1)
            sp1.innerHTML = "<img src= b.jpg>輸入內容有非中文，請重新輸入";
        else
            sp1.innerHTML = "<img src= a.jpg>正確";
    } else {
        sp1.innerHTML = "<img src= b.jpg>姓名至少輸入2個字元";
    }

}






function checkPwd() {
    //取得idPwd元素
    let thePwdObj = document.getElementById("idPwd");
    console.log(`${thePwdObj}`);

    //取得idPwd元素值
    let thePwdObjVal = thePwdObj.value;
    console.log(thePwdObjVal);
    console.log(typeof thePwdObjVal);
    //判斷元素值是否為空白，密碼長度是否大於6
    //如果長度是否大於6，判斷是否包含字母、數字、特殊符號
    let sp = document.getElementById("idsp");
    let thePwdObjValLen = thePwdObjVal.length;
    let flag1 = false, flag2 = false, flag3 = false;


    if (thePwdObjVal == "") {
        sp.innerHTML = "請輸入密碼";

    }

    else if (thePwdObjValLen >= 6) {
        // sp.innerHTML="密碼長度有大於等於6";
        for (let i = 0; i <= thePwdObjValLen; i++) {
            let ch = thePwdObjVal.charAt(i,1).toUpperCase();


            if ("A" <= ch && ch <= "Z")

                flag1 = true;

            else if (0 <= ch && ch <= 9)

                flag2 = true;

            else if (ch == "!" || ch== "@"||ch== "#"||ch=="$"||ch=="%"||ch=="^"||ch=="&"||ch=="*")

                flag3 = true;

            if (flag1 == true && flag2 == true && flag3== true)

                break;

        }

        if (flag1 && flag2 && flag3)
            sp.innerHTML = "<img src= a.jpg>正確";

        else
            sp.innerHTML = "<img src= b.jpg>錯誤";

    }


    else {
        sp.innerHTML = "<img src= b.jpg>密碼長度沒有大於等於6";
    }


}


  function checkDate() {
    let theDateObj = document.getElementById("date1");
    let theDateObjVal = theDateObj.value;
    let sp = document.getElementById("datesp")

    if (!isDateExit(theDateObjVal)) 
        sp.innerHTML = "<img src= b.jpg> 無此日期";
    else
        sp.innerHTML = "<img src= a.jpg> 正確";
}
  
function isDateExit(theDateObjVal) {
    let dateObj = theDateObjVal.split('/');

    let limitDate = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    let theYear = parseInt(dateObj[0]);
    let theMonth = parseInt(dateObj[1]);
    let theDate = parseInt(dateObj[2]);

    let isLeap = new Date(theYear, 1, 29).getDate() === 29;//判斷是否閏年

    if (isLeap) {
        limitDate[1] = 29;
    }

    return theDate <= limitDate[theMonth - 1];
}
