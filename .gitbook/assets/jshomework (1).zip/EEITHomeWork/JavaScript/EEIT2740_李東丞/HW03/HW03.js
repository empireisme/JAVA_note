let clicked = false;
document.addEventListener("DOMContentLoaded", function () {
    let imgs = document.querySelectorAll("img");
    for (let img of imgs) {
        img.addEventListener("mouseover", mouseOver);
        img.addEventListener("mouseout", mouseOut);
        img.addEventListener("click", Click);
        img.addEventListener("dblclick", dblClick);
    }
    document.getElementById("iddiv").addEventListener("dblclick", dblClick);
});

function mouseOver() {
    if (!clicked) {
        let imgs = document.querySelectorAll("img");
        imgsLen = this.id.substr(-1);
        console.log(imgsLen);
        for (let i = 0; i < imgsLen; i++) {
            imgs[i].src = "chngstar1.gif";
        }
        document.getElementById("idRating").innerHTML = "評分為..." + imgsLen;
    }
}
function mouseOut() {
    if (!clicked) {
        let imgs = document.querySelectorAll("img");
        // imgsNum = this.id.substr(-1);
        imgsLen = imgs.length;
        for (let i = 0; i < imgsLen; i++) {
            imgs[i].src = "chngstar0.gif";
        }
        document.getElementById("idRating").innerHTML = "評分為...";
    }
}
function Click() {
    clicked = true;
    let imgs = document.querySelectorAll("img");
    imgsLen = this.id.substr(-1);
    console.log(imgsLen);
    for (let i = 0; i < imgsLen; i++) {
        imgs[i].src = "chngstar1.gif";
    }
    for (let i = imgsLen; i < imgs.length; i++) {
        imgs[i].src = "chngstar0.gif";
    }
    document.getElementById("idRating").innerHTML = "你給" + imgsLen + "顆星";
}
function dblClick() {
    clicked = false;
    let imgs = document.querySelectorAll("img");
    for (let img of imgs) {
        img.src = "chngstar0.gif";
    }
    document.getElementById("idRating").innerHTML = "評分為...";
}