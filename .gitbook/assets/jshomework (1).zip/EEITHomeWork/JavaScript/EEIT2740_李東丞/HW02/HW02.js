function checkName() {
    let theNameObj = document.getElementById("idName");
    let theNameObjVal = theNameObj.value;
    let isChinese = true;
    let sp1 = document.getElementById("idsp1");
    let theNameObjValLen = theNameObjVal.length;
    // console.log(theNameObjVal);
    // console.log(theNameObjValLen);
    if (theNameObjVal == "") {
        sp1.innerHTML = "<img src='error.png'>姓名不可為空白";
    } else if (theNameObjValLen < 2) {
        sp1.innerHTML = "<img src='error.png'>姓名不可少於兩個字";
    }
    else {
        for (let i = 0; i < theNameObjValLen; i++) {
            let charCH = theNameObjVal.charCodeAt(i);
            // console.log(charCH);
            if (charCH < 0x4e00 || charCH > 0x9fff)
                isChinese = false;
        }
        if (isChinese) {
            sp1.innerHTML = "<img src='correct.png'>正確"
        } else {
            sp1.innerHTML = "<img src='error.png'>姓名必須全部為中文字"
        }
    }
}
function checkPwd() {
    let thePwdObj = document.getElementById("idPwd");
    // console.log(thePwdObj);
    let thePwdObjVal = thePwdObj.value;
    // console.log(thePwdObjVal);
    // console.log(typeof thePwdObjVal);
    let includeEnletter = false;
    let includeNum = false;
    let includeSpecialchar = false;

    let sp2 = document.getElementById("idsp2");
    let thePwdObjValLen = thePwdObjVal.length;

    if (thePwdObjVal == "") {
        sp2.innerHTML = "<img src='error.png'>不可空白";;//是否空白  
    } else if (thePwdObjValLen < 6) {
        sp2.innerHTML = "<img src='error.png'>密碼至少要6個字";//至少6個
    } else {
        for (let i = 0; i < thePwdObjValLen; i++) {
            let charEN = thePwdObjVal.charAt(i).toUpperCase();

            if (charEN >= "A" && charEN <= "Z")
                includeEnletter = true;
            if (includeEnletter)
                break;
        }
        if (includeEnletter) {
            sp2.innerHTML = "<img src='correct.png'>正確"
        } else {
            sp2.innerHTML = "<img src='error.png'>錯誤"
        }
    }
}
function checkDate() {
    let sp3 = document.getElementById("idsp3");
    let theDateObj = document.getElementById("idDate");
    let theDateObjVal = theDateObj.value;
    let dateFormat = true;
    //輸入要1900年後才符合格式
    let re = /^(19|[2-9][0-9])[0-9]{2}\/(1[0-2]|0?[1-9])\/(3[0-1]|[1-2][0-9]|0?[1-9])$/;
    //沒有限制
    // let re = /^[1-9]([0-9]{3}|[0-9]{2}|[0-9]?)\/(1[0-2]|0?[1-9])\/(3[0-1]|[1-2][0-9]|0?[1-9])$/;
    

    if (re.test(theDateObjVal)) {
        let date = theDateObjVal.split("/");
        let year = date[0];
        let month = date[1];
        let day = date[2];
        if (month == "2" || month == "02") {
            if (day > "29") {
                dateFormat = false;
            }
            if (day == "29") {

                if (year % 100 == 0 && year % 400 != 0) {
                    dateFormat = false;
                } else if (year % 4 != 0) {
                    dateFormat = false;
                }
                // if(year % 4 != 0){
                //     dateFormat = false;
                // }else if(year % 100 != 0){
                //     dateFormat = false;
                // }else if(year % 400 !=0){
                //     dateFormat = false;
                // }
            }
        }
    } else {
        dateFormat = false;
    }
    if (dateFormat) {
        sp3.innerHTML = "<img src='correct.png'>正確"
    } else {
        sp3.innerHTML = "<img src='error.png'>日期格式錯誤"
    }

}