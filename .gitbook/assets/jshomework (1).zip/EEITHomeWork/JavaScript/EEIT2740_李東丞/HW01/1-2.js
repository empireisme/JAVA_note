
function f() {
    let str = "<table>";
    for (var i = 1; i < 10; i++) {
        str+="<tr>";
        for (var j = 2; j < 10; j++) {
            str += "<td>" + j + "*" + i + "=" + j * i + "</td>";
        }
        str+="</tr>";
    }
    str+="</table>";
    document.getElementById("iddiv").innerHTML=str;
}
f();