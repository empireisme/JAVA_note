let tr1 = document.getElementById('tr1');
let tr2 = document.getElementById('tr2');
let tr3 = document.getElementById('tr3');
let tr4 = document.getElementById('tr4');
let tr5 = document.getElementById('tr5');
let tr6 = document.getElementById('tr6');
let tr7 = document.getElementById('tr7');
let tr8 = document.getElementById('tr8');
let tr9 = document.getElementById('tr9');

function f() {

    for (var i = 1; i < 10; i++) {
        let tr = i;
        switch (tr) {
            case 1:
                for (var j = 2; j < 10; j++) {
                    tr1.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
            case 2:
                for (var j = 2; j < 10; j++) {
                    tr2.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
            case 3:
                for (var j = 2; j < 10; j++) {
                    tr3.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
            case 4:
                for (var j = 2; j < 10; j++) {
                    tr4.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
            case 5:
                for (var j = 2; j < 10; j++) {
                    tr5.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
            case 6:
                for (var j = 2; j < 10; j++) {
                    tr6.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
            case 7:
                for (var j = 2; j < 10; j++) {
                    tr7.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
            case 8:
                for (var j = 2; j < 10; j++) {
                    tr8.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
            case 9:
                for (var j = 2; j < 10; j++) {
                    tr9.innerHTML += "<td>" + j + "*" + i + "=" + j * i + "</td>";
                }
                break;
        }

    }
}
f();

