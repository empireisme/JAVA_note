document.addEventListener("DOMContentLoaded",
    function () {
        var date1 = document.getElementById("d1");
        date1.onblur = function () {
            let date = new Date()
            let ifdate = new Date(date1.value)
            let dsp = document.getElementById("datesp");
            let dimg=document.getElementById("dimg");
            if (ifdate < date) {
                dsp.innerHTML="正確"
                dimg.src=""
            } else {
                dsp.innerHTML="請輸入正確日期"
                dimg.src="error.png"
            }
        }
        var name = document.getElementById("account");
        name.onblur = function () {
            t1 = /^[\u4e00-\u9fa5]{2,}$/;
            let namev = name.value;
            let nsp = document.getElementById("namesp");
            let nimg=document.getElementById("nimg");
            if (t1.test(namev)) {
                nsp.innerHTML = "正確"
                nimg.src=""
            } else {
                nsp.innerHTML = "請輸入2字以上中文"
                nimg.src="error.png"

            }
        }
        var pwd = document.getElementById("pwd");
        pwd.onblur = function () {
            let pwdv = pwd.value;
            t2 = /^(?=.*[A-Za-z])(?=.*[!@#$%^&*])(?=.*[0-9])([A-Za-z!@#$%^&*0-9]{6,})$/;
            let pimg=document.getElementById("pimg");
            let psp = document.getElementById("pwdsp");
            if (t2.test(pwdv)) {
                psp.innerHTML = "正確"
                pimg.src=""
            }else {
                psp.innerHTML = "請輸入至少6位數包含英數與特殊字元"
                pimg.src="error.png"
            }
        }
    })