document.write(`<table id=t> </table>`);
let t=document.getElementById("t");
var s=`<th colspan="8"> 99乘法表</th>`;

for(let i=1;i<10;i++){
    s+="<tr>";
    for(let j=2;j<10;j++){
        s+=`<td>${j}*${i}=${j*i}</td>`
    }
    s+="</tr>"
}
t.innerHTML=s;