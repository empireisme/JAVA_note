document.addEventListener("DOMContentLoaded", function () {
    var i = true;
    var img = document.getElementsByTagName("img");
    for (let j = 0; j < img.length; j++) {
        img[j].addEventListener("mouseover", light)
    }
    document.getElementById("fi0").addEventListener("mouseout", light)
    function light() {
        if (i) {
            let lightid = parseInt(this.id.substr(2));
            for (let p = 0; p < lightid; p++) {
                img[p].src = "chngstar.gif"
            }
            let darkid = 5 - lightid;
            for (let p = 0; p < darkid; p++) {
                img[lightid + p].src = "star.gif"
            }
            if(lightid==0){document.getElementById("p1").innerHTML=``}
            else{document.getElementById("p1").innerHTML=`${lightid}顆星評價`}
        }
    }
    document.getElementById("fi0").addEventListener("click", function () {
        i = false;
    })
    document.getElementById("fi0").addEventListener("dblclick", function () {
        i = true;
        for (let p = 0; p < img.length; p++) {
            img[p].src = "star.gif"
        }
        document.getElementById("p1").innerHTML=``
    })
})