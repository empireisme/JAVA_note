var imglist = ["星1.png", "星2.png", "星3.png", "星4.png", "星5.png"];
var str = "";
for (let j = 0; j < imglist.length; j++) {
    str = str + `<a href="${imglist[j]}"><img id="img${j}" src=${imglist[j]}></a>`
}
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("fi1").innerHTML = str
    let im1 = document.getElementById("im1");
    let img = document.getElementsByTagName("img");
    let sbut=document.getElementById("stop");
    var fkey = 0;
    var key = 0;
    var onoff = true;
    var onoff2 = true;
    function img1() {
        frame();
        img1Href();
        im1.src = imglist[key++];
        if (key == imglist.length) {
            key = 0;
        }
    }
    function img1Href() {
        document.getElementById("a").href = imglist[key]
    }
    function frame() {
        document.getElementById(`img${key}`).style.border = `2px solid rgb(16, 165, 252)`;
        if (fkey != key) { document.getElementById(`img${fkey}`).style.border = `none`; }
        fkey = key;
    }
    for (let j = 1; j < img.length; j++) {
        img[j].addEventListener("mouseover", im)
        img[j].addEventListener("mouseout", re)
    }
    img1()
    var iid = setInterval(img1, 2000);
    function im() {
        i = parseInt(this.id.substr(3));
        im1.src = imglist[i];
        if (fkey != i) {
            document.getElementById(`img${fkey}`).style.border = `none`
            this.style.border = `2px solid rgb(16, 165, 252)`
        }
        key = fkey;
        if (onoff2) {
            imgSwitch();
        }
    }
    function re() {
        im1.src = imglist[key];
        this.style.border = `none`
        document.getElementById(`img${fkey}`).style.border = `2px solid rgb(16, 165, 252)`
        if (onoff2) {
            imgSwitch();
        }
    }
    document.getElementById("lastbut").addEventListener("click", function () {
        key = fkey;
        key--;
        if (key < 0) (
            key = imglist.length - 1
        )
        im1.src = imglist[key];
        frame();
        img1Href()
    })
    document.getElementById("nextbut").addEventListener("click", function () {
        key = fkey;
        key++;
        if (key == imglist.length) (
            key = 0
        )
        im1.src = imglist[key];
        frame();
        img1Href()
    })
    sbut.addEventListener("click", function () {
        imgSwitch();
        if (onoff2) {
            onoff2 = false;
        } else {
            onoff2 = true;
        }
    })
    function imgSwitch() {
        if (onoff) {
            clearInterval(iid);
            sbut.value = "播放";
            onoff = false;
        } else {
            iid = setInterval(img1, 2000);
            onoff = true;
            sbut.value = "停止";
        }
    }
})