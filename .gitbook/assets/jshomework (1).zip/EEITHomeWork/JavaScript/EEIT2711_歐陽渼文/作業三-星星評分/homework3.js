//制作一個星星評分
var divStars = document.getElementById("stars");
var divComment = document.getElementById("comment");
var attitude = ["一顆星", "兩顆星", "三顆星", "四顆星", "五顆星"];
var starNum = -1; //記錄當前第幾顆星星被點擊
var starArray = Array.from(divStars.children); //星星陣列
var starReset = -1; //reset切換
//滑鼠移入
divStars.onmouseover = function (e) 
{
    if (e.target.tagName === "IMG") 
    {   //事件源是圖片
        //把滑鼠移動到的星星替換圖片
        e.target.src = "chngstar.gif";
        //把滑鼠移動到的星星之前的星星替換圖片
        var prev = e.target.previousElementSibling;
        while (prev) 
        {
            prev.src = "chngstar.gif";
            prev = prev.previousElementSibling;
        }
        //把滑鼠移動到的星星之後的星星替換圖片
        var next = e.target.nextElementSibling;
        while (next) 
        {
            next.src = "star.gif";
            next = next.nextElementSibling;
        }

        var index = starArray.indexOf(e.target); //找到滑鼠移動到的星星的索引
        divComment.innerHTML = attitude[index]; //顯示對應的評論
    }
}

//滑鼠點擊
divStars.onclick = function (e) 
{
    if (e.target.tagName === "IMG") 
    {
        //記錄當前點擊的星星索引
        starNum = starArray.indexOf(e.target);
    }
    starReset = -1;
}

//滑鼠移出
divStars.onmouseout = function (e) 
{
    if (starNum !== -1 && starReset == -1) 
    { //滑鼠點擊事件發生，將評分固定在點擊的星星上
        for (var i = 0; i < divStars.children.length; i++) 
        {
            if (i <= starNum) 
            {
                divStars.children[i].src = "chngstar.gif";
            }
            else 
            {
                divStars.children[i].src = "star.gif";
            }
        }

        divComment.innerHTML = "您給的評分為:" + attitude[starNum]; //顯示對應的評論
    }
    else 
    {
        for (var i = 0; i < divStars.children.length; i++)
        {
            divStars.children[i].src = "star.gif";
        }
        divComment.innerHTML = ""; //不顯示評論
    }
}

//點集兩下Reset重製
divStars.ondblclick = function (e) 
{
    starReset = 0;
    if (e.target.tagName === "IMG") 
    {
        for (var i = 0; i < divStars.children.length; i++) 
        {
            divStars.children[i].src = "star.gif";
        }
        divComment.innerHTML = "已為您重置";
    }
}

