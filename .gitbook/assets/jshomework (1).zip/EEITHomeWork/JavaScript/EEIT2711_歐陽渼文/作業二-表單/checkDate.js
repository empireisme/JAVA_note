document.getElementById("idate").onblur = checkDate; 
function checkDate(theDateObjVal) //日期驗證
{

  let sp = document.getElementById("idsp2");
  let theDateObj = document.getElementById("idate");
  theDateObjVal = theDateObj.value;

  // 定義每月天數
  var DA = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  //判斷日期是否是yyyy/mm/dd格式
  if (theDateObjVal.indexOf("/") == -1) 
  {
    sp.style.color = "red";
    sp.innerHTML = "請輸入yyyy-mm-dd格式";
    return false;
  }

  // 分解出年月日
  arrD = theDateObjVal.split("/");
  if (arrD.length != 3) 
  {
    sp.style.color = "red";
    sp.innerHTML = "請輸入yyyy-mm-dd格式";
    return false;
  }

  y = parseInt(arrD[0], 10);
  m = parseInt(arrD[1], 10);
  d = parseInt(arrD[2], 10);


  //判斷輸入是否為數字
  if (isNaN(y) || isNaN(m) || isNaN(d)) 
  {
    sp.style.color = "red";
    sp.innerHTML = "<img src='no.png'>輸入錯誤";
    return false;
  }
  // 判斷月份
  if (m > 12 || m < 1) 
  {
    sp.style.color = "red";
    sp.innerHTML = "<img src='no.png'>輸入錯誤";
    return false;
  }
  //判斷是否為閏月
  if (isLoopYear(y)) DA[2] = 29;

  //判斷輸入的日子是否超過當月天數
  if (d > DA[m]) 
  {
    sp.style.color = "red";
    sp.innerHTML = "<img src='no.png'>輸入錯誤";
    return false;
  }
  sp.style.color = "green";
  sp.innerHTML = "<img src='yes.png'>輸入正確";
  return true;
}


function isLoopYear(theYear) 
{
  return (new Date(theYear, 1, 29).getDate() == 29);

}




