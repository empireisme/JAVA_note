document.getElementById("account1").onblur = checkName;

function checkName() //姓名驗證
{
    let theNameObj = document.getElementById("account1");
    console.log(theNameObj);

    let theNameObjVal = theNameObj.value;
    console.log(theNameObjVal);
    console.log(typeof theNameObjVal);


    let sp = document.getElementById("idsp1");
    let theNameObjValLen = theNameObjVal.length;

    if (theNameObjVal == "")
        sp.innerHTML = "此欄位必填!";

    if(theNameObjValLen < 2)
        sp.innerHTML="請至少填入2個中文字"

    if (theNameObjValLen >= 2) 
    {
        for (let i = 0; i < theNameObjValLen; i++) 
        {
            let ch = theNameObjVal.charAt(i);
            var regName = /^[\u4e00-\u9fa5]{2,4}$/;
            if (regName.test(theNameObjVal)) 
            {
                sp.style.color = "green";
                sp.innerHTML = "<img src='yes.png'>通過驗證";
                return true;
            }
            else 
            {
                sp.style.color = "red";
                sp.innerHTML = "<img src='no.png'>格式錯誤請重新輸入";
                return false;

            }
       }
    }
}
function left_zero_4(theNameObjVal) 
{
    if (str != null && theNameObjVal != '' && theNameObjVal != 'undefined') 
    {
        if (str.length == 2) 
        {
            return '00' + theNameObjVal;
        }
    }
    return theNameObjVal;
}
function unicode(theNameObjVal) //轉換成Unicode
{
    var value = '';
    for (var i = 0; i < theNameObjValLen; i) 
    {
        value = '\\u'; left_zero_4(parseInt(str.charCodeAt(i)).toString(16));
    }
    return value;
}


