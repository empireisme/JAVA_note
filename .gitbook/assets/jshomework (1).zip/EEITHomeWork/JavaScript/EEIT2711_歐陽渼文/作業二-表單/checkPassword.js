document.getElementById("idPwd").onblur = checkPwd;
// 密碼驗證
function checkPwd() 
{
    let thePwdObj = document.getElementById("idPwd");
    console.log(thePwdObj);

    let thePwdObjVal = thePwdObj.value;
    console.log(thePwdObjVal);
    console.log(typeof thePwdObjVal);

    let sp = document.getElementById("idsp");
    let thePwdObjValLen = thePwdObjVal.length;
    let flag1 = false, flag2 = false, flag3 = false;

    //輸入的為空值時，會顯示"此欄位必填"
    if (thePwdObjVal == "") 
    {
        sp.style.color = "red";
        sp.innerHTML = "此欄位必填!";
    }
    // 密碼長度大於等於六才會進for迴圈
    else if (thePwdObjValLen >= 6) 
    {
        for (let i = 0; i < thePwdObjValLen; i++) 
        {
            let ch = thePwdObjVal.charAt(i).toUpperCase();
            let ansii = thePwdObjVal.charCodeAt(i);
            console.log(ansii);
            if (ch >= "A" && ch <= "Z") //判斷是否為英文
            {
                flag1 = true;
            }
            else if (ch >= "0" && ch <= "9")  //判斷是否為數字
            {
                flag2 = true;
            }
            else if (ansii == "33" || (ansii >= "35" && ansii <= "38") || ansii == "42" || ansii == "64" || ansii == "94") 
            {//判斷是否為8個特殊符號
                flag3 = true;
            }
            if (flag1 && flag2 && flag3) break;

        }
        if (flag1 && flag2 && flag3) 
        {
            sp.style.color = "green";
            sp.innerHTML = "<img src='yes.png'>驗證通過";
        }
        else 
        {
            sp.style.color = "red";
            sp.innerHTML = "<img src='no.png'>不正確!請重新輸入";
        }
    } 
    else 
    {
        sp.style.color = "red";
        sp.innerHTML = "密碼長度至少6個字以上";
    }
}
