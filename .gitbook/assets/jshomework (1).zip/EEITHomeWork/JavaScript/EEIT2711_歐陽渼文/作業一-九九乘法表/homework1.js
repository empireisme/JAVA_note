document.write("<table>");      //<table></table>添加一個表格樣式來顯示乘法表 
document.write("<th colspan='8'>九九乘法表</th>");

        for (var x = 1; x <= 9; x++) 
        {
            document.write("<tr>"); 
                
            for (var y = 2; y <= 9; y++) 
            {
                document.write("<td>" + y + " x " + x + " = " + y * x + "</td>");
            }
            document.write("</tr>");
        }
        document.write("</table>");