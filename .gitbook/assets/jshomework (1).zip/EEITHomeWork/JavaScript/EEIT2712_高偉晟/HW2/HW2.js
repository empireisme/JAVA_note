
document.getElementById("idName").addEventListener("blur", checkName);
document.getElementById("idPwd").addEventListener("blur", checkPwdReg);
document.getElementById("idDate").addEventListener("blur", checkDate);



function checkDate() {

    let dat = document.getElementById("idDate").value;

    var dateObj = dat.split('/'); // yyyy/mm/dd

    //列出12個月，每月最大日期限制
    var limitInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    var theYear = parseInt(dateObj[0]);
    var theMonth = parseInt(dateObj[1]);
    var theDay = parseInt(dateObj[2]);
    var isLeap = new Date(theYear, 1, 29).getDate() === 29; // 是否為閏年?

    if (isLeap) {
        // 若為閏年，最大日期限制改為 29
        limitInMonth[1] = 29;
    }

    // 比對該日是否超過每個月份最大日期限制
    if (theDay <= limitInMonth[theMonth - 1]) {
        document.getElementById("idspDate").innerHTML = `<img id="idstar1" class="off" src="correct.jpg" />格式正確`;
    }
    else {
        document.getElementById("idspDate").innerHTML = `<img id="idstar1" class="off" src="error.jpg" />格式錯誤`;

    }

}

function checkPwdReg() {

    let sp = document.getElementById("idspPwd");
    let pwdValue = document.getElementById("idPwd").value;

    let re = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*])[a-zA-Z\d!@#$%^&*]{6,}$/;

    if (re.test(pwdValue))
        sp.innerHTML = `<img id="idstar1" class="off" src="correct.jpg" />密碼格式正確`;
    else
        sp.innerHTML = `<img id="idstar1" class="off" src="error.jpg" />密碼格式錯誤`;



}

function checkName() {
    let theNameObj = document.getElementById("idName");
    let theNameObjVal = theNameObj.value;

    let sp = document.getElementById("idspName");
    let theNameObjValLen = theNameObjVal.length;
    let flag1 = false, flag2 = false, flag3 = false;

    if (theNameObjVal == "")
        sp.innerHTML = `<img id="idstar1" class="off" src="error.jpg" />必須要輸入不能空白`;
    else if (theNameObjValLen >= 2) {
        for (let i = 0; i < theNameObjValLen; i++) {
            let ch = theNameObjVal.charAt(i);
            if (ch >= "\u4E00" && ch <= "\u9FFF")
                flag1 = true;
            else {
                flag1 = false;
                break;
            }
        }
        if (flag1 == true)
            sp.innerHTML = `<img id="idstar1" class="off" src="correct.jpg" />正確`;
        if (flag1 == false)
            sp.innerHTML = `<img id="idstar1" class="off" src="error.jpg" />請輸入中文字`;
    } else {
        sp.innerHTML = `<img id="idstar1" class="off" src="error.jpg" />名字至少要兩個中文字`;
    }
}
