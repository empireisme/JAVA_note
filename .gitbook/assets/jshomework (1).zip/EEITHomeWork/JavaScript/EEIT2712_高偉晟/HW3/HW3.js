let flag1 = true;
document.addEventListener("DOMContentLoaded", function () {
    let imgs = document.querySelectorAll("img");
    let imgsLen = imgs.length;


    for (let img of imgs) {
        img.addEventListener("mouseover", mouseOver);
        img.addEventListener("mouseout", mouseOut);
        img.addEventListener("click", Click);
        img.addEventListener("dblclick", dblClick);
    }
});
function mouseOver() {
    if (flag1) {
        for (let i = 0; i < this.id.substr(6); i++) {
            document.images[i].className = "on";
        }
        document.getElementById("stardiv").innerHTML = `評分為：${this.id.substr(6)}`;
    }
}
function mouseOut() {
    if (flag1) {
        for (let i = 0; i < this.id.substr(6); i++) {
            document.images[i].className = "off";
        }
        document.getElementById("stardiv").innerHTML = ``;

    }
}
function Click() {
    if (flag1) {
        for (let i = 0; i < this.id.substr(6); i++) {
            document.images[i].style.filter = `grayscale(0)`;
        }
        document.getElementById("divScore").innerHTML = `你給了${this.id.substr(6)}顆星`;
        document.getElementById("stardiv").innerHTML = ``;
        flag1 = false;
    }
}


function dblClick() {
    flag1 = true
    if (flag1) {
        for (let i = 0; i < 5; i++) {
            document.images[i].removeAttribute("style");
        }
        document.getElementById("divScore").innerHTML = ``;
        document.getElementById("stardiv").innerHTML = ``;
    }
}