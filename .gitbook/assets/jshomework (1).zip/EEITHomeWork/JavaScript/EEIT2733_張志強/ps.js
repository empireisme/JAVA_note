document.getElementById("idName").onblur = checkName;
function checkName() {
    let sp = document.getElementById("idsp");
    let theNVal = document.getElementById("idName").value;
    let re = /[\u4E00-\u9FA5]/;

    if (theNVal == "") {
        sp.innerHTML = "<img src=\"Images/error.png\">you must enter";
    } else if (theNVal.length < 3) {
        sp.innerHTML = "<img src=\"Images/error.png\">name too short";
    } else if (re.test(theNVal) != true) {
        sp.innerHTML = "<img src=\"Images/error.png\">please use chinese";
    } else {
        sp.innerHTML = "<img src=\"Images/correct.png\">correct";
    }
}

document.getElementById("idPwd").onblur = checkPwd;
function checkPwd() {
    let sp1 = document.getElementById("idsp1");
    let thePWVal = document.getElementById("idPwd").value;
    let re = /[A-Za-z]/;
    let re1 = /[1-9][0-9]/;
    let re2 = /[!@#$%^&*]/;

    if (thePWVal == "") {
        sp1.innerHTML = "<img src=\"Images/error.png\">you must enter";
    } else if (thePWVal.length < 6) {
        sp1.innerHTML = "<img src=\"Images/error.png\">Password too short";
    } else if (re.test(thePWVal) != true) {
        sp1.innerHTML = "<img src=\"Images/error.png\">please use english character";
    } else if (re1.test(thePWVal) != true) {
        sp1.innerHTML = "<img src=\"Images/error.png\">please use numbers";
    } else if (re2.test(thePWVal) != true) {
        sp1.innerHTML = "<img src=\"Images/error.png\">please use special symbol";
    } else {
        sp1.innerHTML = "<img src=\"Images/correct.png\">correct";
    }
}

document.getElementById("idDate").onblur = checkDate;
function checkDate() {
    let sp2 = document.getElementById("idsp2");
    let theDVal = document.getElementById("idDate").value;
    let re = /^(([12][0-9])?[0-9]{2}[/](0?[1-9]|1[012])[/](0?[1-9]|[12][0-9]|3[01]))*$/;

    if (theDVal == "") {
        sp2.innerHTML = "<img src=\"Images/error.png\">you must enter";
    } else if (re.test(theDVal)!=true) {
        sp2.innerHTML = "<img src=\"Images/error.png\">incorrect";
    } else if (re.test(theDVal)) {
        if (isExistDate(theDVal) != true) {
            sp2.innerHTML = "<img src=\"Images/error.png\">date not exist";
        } else {
            sp2.innerHTML = "<img src=\"Images/correct.png\">correct";
        }
    }
}

function isExistDate() {
    let theDVal = document.getElementById("idDate").value;
    let d = theDVal.split("/");//陣列
    let limitInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; //列出12個月，每月最大日期限制
    let theYear = parseInt(d[0]);
    let theMonth = parseInt(d[1]);
    let theDay = parseInt(d[2]);
    let isLeap = new Date(theYear, 1, 29).getDate() === 29;// 是否為閏年?
    if (isLeap) {// 若為閏年，最大日期限制改為 29
        limitInMonth[1] = 29;
    }
    return theDay <= limitInMonth[theMonth - 1]//比對該月的最大日期限制 [index]->該月
}