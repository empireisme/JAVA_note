document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("figc2").innerHTML = "單擊星星可評分，雙擊星星重製";
    var img = document.querySelectorAll('img.s');
    var imgLen = img.length;
    var num;//變量
    onoff = true;//開關

    for (var i = 0; i < imgLen; i++) {
        img[i].index = i;
        img[i].onmouseover = function () {
            if (onoff) {
                for (let j = 0; j < imgLen; j++) {//初始化,全滅
                    img[j].className = 's';
                    document.getElementById("figc1").innerHTML = "";
                }
                for (let j = 0; j <= this.index; j++) {//點亮猩猩
                    img[j].className = 'n';
                    document.getElementById("figc1").innerHTML = "評分為..." + (j + 1);
                }
            }
        };

        img[i].onmouseout = function () {
            if (onoff) {
                for (let j = 0; j < imgLen; j++) {//初始化,全滅
                    img[j].className = 's';
                    document.getElementById("figc1").innerHTML = "";
                }
                for (let j = 0; j <= num; j++) {//移出 滅
                    img[j].className = 's';
                }
            }
        };

        img[i].onclick = function () {
            onoff = false;
            for (let j = 0; j < imgLen; j++) {//初始化,全滅
                img[j].className = 's';
                document.getElementById("figc1").innerHTML = "";
            }
            num = this.index;//點擊時，把當前的星星的index給變量，點亮之前的星星
            for (let j = 0; j <= num; j++) {
                img[j].className = 'n';
                document.getElementById("figc1").innerHTML = "你給" + (num + 1) + "顆星";
            }
        };

        img[i].ondblclick = function () {
            onoff = false;
            for (let j = 0; j < imgLen; j++) {//初始化,全滅
                img[j].className = 's';
                document.getElementById("figc1").innerHTML = "";
            }
            for (let j = 0; j < imgLen; j++) {//初始化,全滅
                img[j].className = 's';
                document.getElementById("figc1").innerHTML = "";
            } return onoff = true;
        };
    }
});