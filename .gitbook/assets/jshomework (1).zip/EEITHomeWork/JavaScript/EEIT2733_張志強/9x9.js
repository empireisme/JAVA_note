// document.write("<table class=\"st1\">");
// for (let i = 1; i < 10; i++) {
//     document.write("<tr>");
//     for (let j = 2; j < 10; j++) {
//         document.write("<td class=\"st1\">" + j + "*" + i + "=" + j * i + "</td>");
//     }
// }
// document.write("</table>");

let str = "<table class=\"st1\">";
for (let i = 1; i < 10; i++) {
    str += "<tr>";
    for (let j = 2; j < 10; j++) {
        str += `<td class=\"st1\">${j}x${i}=${j * i}</td>`;
    }
}
str += "</table>";
document.getElementById("div1").innerHTML = str;