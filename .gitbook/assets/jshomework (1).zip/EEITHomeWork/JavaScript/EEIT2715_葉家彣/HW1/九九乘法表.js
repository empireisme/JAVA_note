//表格起始標籤
document.write("<table>")
//表格表頭
document.write("<caption>使用Table印出九九乘法表</caption>")
//變數宣告
var i, j;
//巢狀迴路
for (i = 2; i <= 9; i++) {
    //儲存格開始標籤
    document.write("<td>")
    for (j = 1; j <= 9; j++) {
        document.write(`${i}*${j}= ${i * j} ` + "<br>");
    }
    //儲存格結束標籤
    document.write("</td>")
}
//表格結束標籤
document.write(" </table>")