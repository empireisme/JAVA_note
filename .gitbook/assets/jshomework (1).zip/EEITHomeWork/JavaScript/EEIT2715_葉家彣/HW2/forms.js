function checkName() {
    //取得元素值
    let theNameObjVal = document.getElementById("idName").value;
    //建立RegExp物件語法 2(literal)
    let re = /^.+[\u4e00-\u9fff]$/;
    //判斷元素值是否為空白，密碼長度是否大等於2
    //如果長度是否大於2，判斷是否是中文字
    let sp = document.getElementById("idspName");
    let theNameObjLen = theNameObjVal.length;
    if (theNameObjVal == "")
        sp.innerHTML = "<img src='叉叉.jpg'>姓名不可空白";
    else if (theNameObjLen >= 2) {
        if (re.test(theNameObjVal))
            sp.innerHTML = "<img src='勾勾.jpg'>正確";
        else
            sp.innerHTML = "<img src='叉叉.jpg'>姓名必須全部是中文字";
    } else {
        sp.innerHTML = "<img src='叉叉.jpg'>姓名至少2個字"
    }

}

//     //取得idName元素
//     let theNameObj = document.getElementById("idName");
//     console.log(theNameObj);
//     //取得idName元素值
//     let theNameObjVal = theNameObj.value;
//     console.log(theNameObjVal);
//     // console.log(typeof theNameObjVal);//string
//     //判斷元素值是否為空白，密碼長度是否大等於2
//     //如果長度是否大於2，判斷是否是中文字
//     let sp = document.getElementById("idspName");
//     let theNameObjLen = theNameObjVal.length;
//     let flag1 = false; flag2 = false; flag3 = false;
//     if (theNameObjVal == "")
//         sp.innerHTML = "姓名不可空白";
//     else if (theNameObjLen >= 2) {
//         for (let i = 0; i < theNameObjValLen; i++) {
//             let ch = theNameObjVal.charCodeAt(i);
//             if (ch >= 0x4e00 && ch <= 0x9fff)
//                 flag1 = true;
//         }
//         if (flag1)
//             sp.innerHTML = "correct";
//         else
//             sp.innerHTML = "姓名必須全部是中文字";
//     } else {
//         sp.innerHTML = "姓名至少2個字"
//     }
// }

function checkPwd() {
    //取得idPwd元素
    let thePwdObj = document.getElementById("idPwd");
    console.log(thePwdObj);
    //取得idPwd元素值
    let thePwdObjVal = thePwdObj.value;
    console.log(thePwdObjVal);
    // console.log(typeof thePwdObjVal);//string
    //判斷日期是否存在
    let sp = document.getElementById("idspPwd");
    let thePwdObjValLen = thePwdObjVal.length;
    let flag1 = false; flag2 = false; flag3 = false;
    let spchar = ["!", "@", "#", "$", "%", "^", "&", "*"];
    if (thePwdObjVal == "")
        sp.innerHTML = "<img src='叉叉.jpg'>密碼不可空白";
    else if (thePwdObjValLen >= 6) {
        // sp.innerHTML = "密碼要大於等於6"
        for (let i = 0; i < thePwdObjValLen; i++) {
            let ch = thePwdObjVal.charAt(i).toUpperCase()
            if (ch >= "A" && ch <= "Z")
                flag1 = true;
            else if (ch >= "0" && ch <= "9")
                flag2 = true;
            else if(thePwdObjVal.includes(spchar[i])) {
                flag3 = true;
            }
            if (flag1 && flag2 && flag3) break;
        }
        if (flag1 && flag2 && flag3)
            sp.innerHTML = "<img src='勾勾.jpg'>正確";
        else
            sp.innerHTML = "<img src='叉叉.jpg'>密碼必須包含英數字、特殊字元[!@#$%^&*]";
    } else {
        sp.innerHTML = "<img src='叉叉.jpg'>密碼至少6個字"
    }
}

function checkDate() {
    let theDateObj = document.getElementById("idDate");
    let theDateObjVal = theDateObj.value;
    let sp = document.getElementById("idspdate")

    if (!isDateExit(theDateObjVal)) 
        sp.innerHTML = "<img src='叉叉.jpg'>無此日期";
    else
        sp.innerHTML = "<img src='勾勾.jpg'>正確";
}
function isDateExit(theDateObjVal) {
    let dateObj = theDateObjVal.split('/');// yyyy/mm/dd
    
    //列出12個月的最後一天
    let limitDate = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    // [yyyy,mm,dd]
    let theYear = parseInt(dateObj[0]);
    let theMonth = parseInt(dateObj[1]);
    let theDate = parseInt(dateObj[2]);
    //判斷是否閏年
    let isLeap = new Date(theYear, 1, 29).getDate() === 29;
    //是閏年 2月變29天
    if (isLeap) {
        limitDate[1] = 29;
    }

    return theDate <= limitDate[theMonth - 1];
}