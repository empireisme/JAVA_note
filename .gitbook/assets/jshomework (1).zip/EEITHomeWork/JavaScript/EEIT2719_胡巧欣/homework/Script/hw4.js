
    //控制廣告圖片
    var ads = document.getElementById("ads");
    //控制上一張
    var prev = document.getElementById("prev");
    //控制下一張
    var next = document.getElementById("next");
    //控制開始
    var start = document.getElementById("start");
    //控制暫停
    var stopp = document.getElementById("stopp");
    //控制盒子
    var box = document.getElementById("box");
    //控制按鈕們
    var buttons = document.getElementById("buttons").getElementsByTagName("img");
    // console.log(buttons); HTMLCollection(7) [img.light, img, img, img, img, img, img]
    //控制按鈕們的編號
    var index = 1;
    //輪播效果
    function animate(dis) {
        //七張圖與box左邊的距離 0 400 800 1200 1600 2000 2400
        //box總長度設為400 只夠顯示第一張圖 其他圖都會在視窗外
        //七張圖要顯示在box nowLeft的值 0 -400 -800 -1200 -2000 -2400
        //參數dis控制box左邊距離的數值
        //移動到視野中 所以一次是-400
        //且style.left獲取的是字符串，需要用parseInt()取整轉化為數字
        //第七張圖的下一張是第一張 nowLeft < -2400 style.left 設定為 0
        //第一張圖的前一張是第七張 nowLeft > 0 style.left 設定為 -2400
        //ads.style.transition 滑動效果 0.7秒執行
        var nowLeft = parseInt(ads.style.left) + dis;
        ads.style.left = nowLeft + "px";
        ads.style.transition = "500ms ease";
        if (nowLeft < -2400) {
            ads.style.left = 0 + "px";
        }
        if (nowLeft > 0) {
            ads.style.left = -2400 + "px";
        }
    }
    //設定計時器
    var time;
    //自動撥放 5秒一次
    function autoplay() {
        time = setInterval(function () {
            next.onclick()
        }, 5000);
    }
    //暫停撥放
    autoplay();
    function stopplay() {
        clearInterval(time);
    }
    //按鈕樣式
    function lightButton() {
        //尋找目前亮的按鈕，樣式改回空
        for (let i = 0; i < buttons.length; i++) {
            if (buttons[i].className == "light") {
                buttons[i].className = "";
            }
        }
        //把目前圖片的按鈕點亮，buttons[i]=buttons[index - 1]
        buttons[index - 1].className = "light";
    }
    //前一張圖片 與左邊距離+400 index遞減 點亮目前選擇圖片按鈕
    prev.onclick = function () {
        index -= 1;
        if (index < 1) {
            index = 7;
        }
        lightButton();
        animate(400);
    }
    //後一張圖片 與左邊距離-400 index遞增 點亮目前選擇圖片按鈕
    next.onclick = function () {
        index += 1;
        if (index > 7) {
            index = 1;
        }
        lightButton();
        animate(-400);
    }
    //按鈕點擊到指定圖片
    //取得點擊圖片index的屬性
    //要位移的距離 dis=(目前圖片的index-點擊圖片index)*400
    //目前圖片的index=點擊圖片index
    //點亮按鈕
    for (var i = 0; i < buttons.length; i++) {
        buttons[i].onclick = function () {
            var clickIndex = parseInt(this.getAttribute("index"));
            var dis = 400 * (index - clickIndex);
            animate(dis);
            index = clickIndex;
            lightButton();
        }
    }
    //滑鼠滑入box(圖片)暫停 圖片顯示title 點擊可連結出去
    box.onmouseover = stopplay;
    //滑鼠滑出box(圖片)繼續撥放
    box.onmouseout = autoplay;
    //點擊暫停播放
    stopp.onclick = stopplay;
    //點擊開始播放
    start.onclick = autoplay;