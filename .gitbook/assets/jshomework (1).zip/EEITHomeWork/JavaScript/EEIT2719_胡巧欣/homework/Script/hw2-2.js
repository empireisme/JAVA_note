function checkPwd() {
    //取得idPwd元素
    let thePwdObj = document.getElementById("idPwd");
    //取得idPwd元素值
    let thePwdObjVal = thePwdObj.value;
    //判斷元素值是否為空白，密碼長度是否大於等於6
    //如果長度是否大於6，判斷是否包含字母、數字、特殊符號
    let sp = document.getElementById("idsp");
    let thePwdObjValLen = thePwdObjVal.length;
    let flag1 = false, flag2 = false, flag3 = false;

    if (thePwdObjVal == "")
    {
       sp.style.color="red";
       sp.innerHTML = "<img src='Image/error.jpg'> 此欄不可空白";
    }
    else if (thePwdObjValLen >= 6) {
        re2 = /[A-Za-z]+/;
        if (re2.test(thePwdObjVal))
            flag1 = true;
        re3 = /[0-9]+/;
        if (re3.test(thePwdObjVal))
            flag2 = true;
        re4 = /[!@#$%^&*]+/;
        if (re4.test(thePwdObjVal))
            flag3 = true;
        if (flag1 && flag2 && flag3)
        {
            sp.style.color="green";
            sp.innerHTML = "<img src='Image/right.jpg'> 輸入正確";
        }
        else
        {
            sp.style.color="red";
            sp.innerHTML = "<img src='Image/error.jpg'> 輸入不符合格式";
        }
    }
    else
    {
        sp.style.color="red";
        sp.innerHTML = "<img src='Image/error.jpg'> 輸入須超過六個字以上";
    }
}