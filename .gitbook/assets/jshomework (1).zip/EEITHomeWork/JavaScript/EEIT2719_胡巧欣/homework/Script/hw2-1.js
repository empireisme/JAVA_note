function checkName() {
    let theNameObj = document.getElementById("idName");
    let theNameObjVal = theNameObj.value;
    //判斷元素值是否為空白，姓名長度是否大於等於2
    //如果長度是否大於2，判斷是否全為中文字
    let sp = document.getElementById("idsp2");
    let theNameObjValLen = theNameObjVal.length;
    if (theNameObjVal == "")
    {
        sp.style.color="red";
        sp.innerHTML = "<img src='Image/error.jpg'> 此欄不可空白";
    }
    else if (theNameObjValLen >= 2) 
    {
        re1 = /[^\u4e00-\u9fff]+/;
        if (re1.test(theNameObjVal))
        {
            sp.style.color="red";
            sp.innerHTML = "<img src='Image/error.jpg'> 輸入非中文"; 
        }

        else
        {
            sp.style.color="green";
            sp.innerHTML = "<img src='Image/right.jpg'> 輸入正確";
        }

    }
    else
    {
        sp.style.color="red";
        sp.innerHTML = "<img src='Image/error.jpg'> 輸入須超過兩個字以上";
    }
}