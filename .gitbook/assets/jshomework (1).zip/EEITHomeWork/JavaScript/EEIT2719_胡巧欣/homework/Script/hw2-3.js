function checkDate() {
    //取得date1元素
    let theDateObj = document.getElementById("date1");
    //取得date1元素值
    let theDateObjVal = theDateObj.value;
    let sp = document.getElementById("idsp3");
    //定義一個月份天數正常數組
    var DA = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    //判斷日期是否是預期的格式
    if (theDateObjVal.indexOf("/") == -1) 
    {
        sp.style.color="red";
        sp.innerHTML = "<img src='Image/error.jpg'> 輸入格式不正確";
    }
    else {
        //分解出年月日
        let arrD = theDateObjVal.split("/");
        if (arrD.length != 3) 
        {
            sp.style.color="red";
            sp.innerHTML = "<img src='Image/error.jpg'> 日期長度不正確";
        }
        else {
            y = parseInt(arrD[0], 10);
            m = parseInt(arrD[1], 10);
            d = parseInt(arrD[2], 10);
            var isLeap = new Date(y, 1, 29).getDate() === 29;
            //判斷年月日是否是數字
            if (isNaN(y) || isNaN(m) || isNaN(d)) 
            {
                sp.style.color="red";
                sp.innerHTML = "<img src='Image/error.jpg'> 輸入非數字";
            }
            else {
                //判斷月份是否在1-12之間
                if (m > 12 || m < 1) 
                {
                    sp.style.color="red";
                    sp.innerHTML = "<img src='Image/error.jpg'> 輸入無效月份";
                }
                else {
                    //判斷是否是閏年
                    if (isLeap) {
                        DA[2] = 29;
                        //判斷輸入的日是否超過了當月月份的總天數
                        if (d > DA[m]) 
                        {
                            sp.style.color="red";
                            sp.innerHTML = "<img src='Image/error.jpg'> 輸入無效日期";
                        }
                        else 
                        {
                            sp.style.color="green";
                            sp.innerHTML = "<img src='Image/right.jpg'> 輸入正確";
                        }
                    }
                    else 
                    {
                        //判斷輸入的日是否超過了當月月份的總天數
                        if (d > DA[m]) 
                        {
                            sp.style.color="red";
                            sp.innerHTML = "<img src='Image/error.jpg'> 輸入無效日期";
                        }
                        else 
                        {
                            sp.style.color="green";
                            sp.innerHTML = "<img src='Image/right.jpg'> 輸入正確";
                        }

                    }


                }
            }
        }
    }
}
