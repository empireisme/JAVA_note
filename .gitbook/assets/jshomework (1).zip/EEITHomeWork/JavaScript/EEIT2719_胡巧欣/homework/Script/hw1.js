let str ="<table>";
str+="<th colspan='8'>九九乘法表</th>";
str+="<tr>";
for (let i = 2; i < 10; i++){
    str +="<td>";
    for (let j = 1; j < 10; j++){
        str +=`${i}*${j}=${i*j}<br>`;
    }
    str +="</td>";
}
str +="</tr></table>";
document.getElementById("div1").innerHTML=str;