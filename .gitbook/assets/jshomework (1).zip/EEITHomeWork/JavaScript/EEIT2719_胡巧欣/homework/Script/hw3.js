var divStars = document.getElementById("stars");
                    var divComment = document.getElementById("comment");
                    var comment = ["1", "2", "3", "4", "5"];
                    var starNum = -1; //記錄當前第幾顆星星被點擊 預設值-1不指向任一
                    var starNum2 = -1;//記錄當前第幾顆星星被雙擊 預設值-1不指向任一
                    var starArray = Array.from(divStars.children); //星星數組
                    //滑鼠移入
                    divStars.onmouseover = function (e) {
                        if (e.target.tagName === "IMG") { //事件源是圖片
                            //把滑鼠移動到的星星替換圖片
                            e.target.src = "Image/star.jpg";
                            e.target.className = "n";
                            //把滑鼠移動到的星星之前的星星替換圖片
                            var prev = e.target.previousElementSibling;
                            while (prev) {
                                prev.src = "Image/star.jpg";
                                prev.className = "n";
                                prev = prev.previousElementSibling;
                            }
                            //把滑鼠移動到的星星之後的星星替換圖片
                            var next = e.target.nextElementSibling;
                            while (next) { //把滑鼠移動到的星星之後的星星替換圖片
                                next.src = "Image/star.jpg";
                                next.className = "s";
                                next = next.nextElementSibling;
                            }

                            var index = starArray.indexOf(e.target); //找到滑鼠移動到的星星的序號
                            divComment.innerHTML = "評分為…"+comment[index]+"分"; //顯示對應的評論
                        }
                    }
                    //滑鼠點擊
                    divStars.onclick = function (e) {
                        if (e.target.tagName === "IMG") {
                            //記錄當前點擊的星星序號
                            starNum = starArray.indexOf(e.target);
                            if (starNum !== -1) { //滑鼠點擊事件發生，將評分固定在點擊的星星上
                                for (var i = 0; i < divStars.children.length; i++) {
                                    if (i <= starNum) {
                                        divStars.children[i].src = "Image/star.jpg";
                                        divStars.children[i].className = "n";

                                    } else {
                                        divStars.children[i].src = "Image/star.jpg";
                                        divStars.children[i].className = "s";
                                    }
                                }
                                divComment.innerHTML = "您給"+comment[starNum]+"顆星"; //顯示對應的評論
                            }
                            else {
                                for (var i = 0; i < divStars.children.length; i++) {
                                    divStars.children[i].src = "Image/star.jpg";
                                    divStars.children[i].className = "s";
                                }
                                divComment.innerHTML = "評分為…"; 
                            }
                        }
                    }
                    //滑鼠雙擊
                    divStars.ondblclick = function (e) {
                        if (e.target.tagName === "IMG") {
                            //記錄當前點擊的星星序號
                            starNum2 = starArray.indexOf(e.target);
                            if (starNum2 == starNum) {
                                //把滑鼠移動到的星星替換圖片
                                e.target.src = "Image/star.jpg";
                                e.target.className = "s";
                                //把滑鼠移動到的星星之前的星星替換圖片
                                var prev = e.target.previousElementSibling;
                                while (prev) {
                                    prev.src = "Image/star.jpg";
                                    prev.className = "s";
                                    prev = prev.previousElementSibling;
                                }
                                divComment.innerHTML = "評分為…"; 
                                starNum=-1;
                                starNum2=-1;
                            }


                        }
                    }
                    //滑鼠移出
                    divStars.onmouseout = function (e) {
                        if (e.target.tagName === "IMG") {
                            if (starNum == -1 && starNum2 == -1) 
                            {
                                e.target.src = "Image/star.jpg";
                                e.target.className = "s";
                                var prev = e.target.previousElementSibling;
                                while (prev) {
                                    prev.src = "Image/star.jpg";
                                    prev.className = "s";
                                    prev = prev.previousElementSibling;
                                }
                                //把滑鼠移動到的星星之後的星星替換圖片
                                var next = e.target.nextElementSibling;
                                while (next) { //把滑鼠移動到的星星之後的星星替換圖片
                                    next.src = "Image/star.jpg";
                                    next.className = "s";
                                    next = next.nextElementSibling;
                                }
                                divComment.innerHTML = "評分為…"; 

                            }else if(starNum !== -1 && starNum2 == -1)
                            {
                                for (var i = 0; i < divStars.children.length; i++) {
                                    if (i <= starNum) {
                                        divStars.children[i].src = "Image/star.jpg";
                                        divStars.children[i].className = "n";

                                    } else {
                                        divStars.children[i].src = "Image/star.jpg";
                                        divStars.children[i].className = "s";
                                    }
                                }
                                divComment.innerHTML = "您給"+comment[starNum]+"顆星"; 

                            }

                        }


                    }



