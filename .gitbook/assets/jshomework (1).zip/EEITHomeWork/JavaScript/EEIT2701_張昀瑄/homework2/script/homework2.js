document.getElementById("name").onblur = checkName;
function checkName() {
    let thenameObj = document.getElementById("name");
    let thenameValue = thenameObj.value;
    console.log(thenameValue);
    let namesp = document.getElementById("namesp");
    let thenameValLen = thenameValue.length;

    if (thenameValue == "") {
        namesp.innerHTML = "<img src='image/error.png'>不可空白";
    } else {
        if (thenameValLen >= 2) {
            let re1 = new RegExp("[^\u4E00-\u9FA5]", "gi");
            if (re1.test(thenameValue)) {
                namesp.innerHTML = "<img src='image/error.png'>必須全部為中文字";
            } else {
                namesp.innerHTML = "<img src='image/Yes_Check.png'>正確";
            }
        }
        else {
            namesp.innerHTML = "<img src='image/error.png'>至少2個字以上";
        }
    }
}

document.getElementById("psw").onblur = checkPwd;
function checkPwd() {
    let thepswObj = document.getElementById("psw");
    let thepswValue = thepswObj.value;
    console.log(thepswValue);
    let pswsp = document.getElementById("pswsp");
    let thePwdValLen = thepswValue.length;

    if (thepswValue == "") {
        pswsp.innerHTML = "<img src='image/error.png'>不可空白";
    } else {
        if (thePwdValLen >= 6) {
            let re1 = /[a-zA-Z]/g;
            let re2 = /[0-9]/g;
            let re3 = /[!@#$%^&*]/g;
            if (re1.test(thepswValue) && re2.test(thepswValue) && re3.test(thepswValue)) {
                pswsp.innerHTML = "<img src='image/Yes_Check.png'>正確";
            } else {
                pswsp.innerHTML = "<img src='image/error.png'>必須包含英數字、特殊字元[!@#$%^&*]";
            }
        }
        else {
            pswsp.innerHTML = "<img src='image/error.png'>至少需要6個字";
        }
    }
}

document.getElementById("date").onblur = checkDate;
function checkDate() {
    let thedateObj = document.getElementById("date");
    let thedateValue = thedateObj.value;
    console.log(thedateValue);
    let datesp = document.getElementById("datesp");
    let re4 = /[0-9]{4}\/[0-9]{2}\/[0-9]{2}/g;
    if (thedateValue == "") {
        datesp.innerHTML = "<img src='image/error.png'>不可空白";
    } else if(re4.test(thedateValue)){
        let arrayDate = thedateValue.split("/");
        let year = parseInt(arrayDate[0]);
        console.log(year);
        let month = parseInt(arrayDate[1]);
        console.log(month);
        let day = parseInt(arrayDate[2]);
        console.log(day);
        if ((year>0)&&(month <= 12) && (month > 0) && (day > 0) && (day <= 31)) {
            if (year % 4 == 0) {//可能為閏年
                if ((year % 100 == 0) && (year % 400 == 0)) {//確定閏年
                    if (month == 2) {
                        if (day <= 29) {
                            datesp.innerHTML = "<img src='image/Yes_Check.png'>正確";
                        } else {
                            datesp.innerHTML = "<img src='image/error.png'>無此日期";
                        }
                    } else {
                        datesp.innerHTML = "<img src='image/Yes_Check.png'>正確";
                    }
                } else if ((year % 100 != 0)) {//確定閏年
                    if (month == 2) {
                        if (day <= 29) {
                            datesp.innerHTML = "<img src='image/Yes_Check.png'>正確";
                        } else {
                            datesp.innerHTML = "<img src='image/error.png'>無此日期";
                        }
                    } else {
                        datesp.innerHTML = "<img src='image/Yes_Check.png'>正確";
                    }
                }
            } else {//非閏年
                if (month == 2) {
                    if (day < 29) {
                        datesp.innerHTML = "<img src='image/Yes_Check.png'>正確";
                    } else {
                        datesp.innerHTML = "<img src='image/error.png'>無此日期";
                    }
                } else {
                    datesp.innerHTML = "<img src='image/Yes_Check.png'>正確";
                }
            }
        } else {
            datesp.innerHTML = "<img src='image/error.png'>無此日期";
        }
    }else{
        datesp.innerHTML = "<img src='image/error.png'>日期格式不符";
    }
}