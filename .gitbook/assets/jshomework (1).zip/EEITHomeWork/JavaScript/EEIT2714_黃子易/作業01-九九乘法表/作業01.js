document.write("<table><tr>");
for (let i = 2; i < 10; i++) {
    document.write("<td>");
    for (let j = 1; j < 10; j++) {
        // console.log(i+"*"+j+"="+i*j);
        // document.write(i+"*"+j+"="+i*j+"<br>");
        // document.getElementById("iddiv").innerHTML+=i+"*"+j+"="+i*j+"<br>"
        document.write(i + "*" + j + "=" + i * j + "<br>");
    }
    document.write("</td>");
}
document.write("</tr></table>");

    // document.write("<table><tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td></tr></table>");