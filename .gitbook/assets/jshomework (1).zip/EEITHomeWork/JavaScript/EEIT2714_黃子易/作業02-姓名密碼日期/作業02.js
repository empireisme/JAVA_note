document.getElementById("account1").onblur = checkAccunt;
/*姓名驗證*/
function checkAccunt() {
    let account = document.getElementById("account1");
    let accountVal = account.value;
    let sp1 = document.getElementById("idsp1");
    var re = /\w/;
    if (accountVal == "") {
        sp1.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>姓名不能為空</a>";
    } else if (re.test(accountVal))
        sp1.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>姓名必須全部為中文</a>";
    else
        sp1.innerHTML = "<img src='Images/正確.png'><a style='color:green'>正確</a>";
}

document.getElementById("idPwd").onblur = checkPwd;
/*密碼驗證*/
function checkPwd() {
    let thePwdObj = document.getElementById("idPwd");
    let thePwdObjVal = thePwdObj.value;
    let sp2 = document.getElementById("idsp2");
    let thePwdObjValLen = thePwdObjVal.length;
    let flag1 = false,
        flag2 = false,
        flag3 = false;

    if (thePwdObjVal == "")
        sp2.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>密碼不能為空</a>";
    else if (thePwdObjValLen < 6) {
        sp2.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>密碼至少6個字元</a>";
    } else {
        for (let i = 0; i < thePwdObjValLen; i++) {
            let ch = thePwdObjVal.charCodeAt(i);
            if (ch >= 48 && ch <= 57) {
                flag1 = true;
            }
            if ((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122)) {
                flag2 = true;
            }
            if ((ch >= 33 && ch <= 47) || (ch >= 58 && ch <= 64) || (ch >= 91 && ch <= 96) || (ch >= 123 && ch <= 126)) {
                flag3 = true;
            }
        }
        if (0 == flag1)
            sp2.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>密碼必須含有數字</a>"
        else if (0 == flag2)
            sp2.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>密碼必須含有字母</a>"
        else if (0 == flag3)
            sp2.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>密碼必須含有特殊字元</a>"
        else
            sp2.innerHTML = "<img src='Images/正確.png'><a style='color:green'>正確</a>";
    }
}
document.getElementById("data1").onblur = checkData;
/*日期驗證*/
function checkData() {
    let dataVal = document.getElementById("data1").value;
    console.log(dataVal);
    let sp3 = document.getElementById("idsp3");
    let re = new RegExp("^([0-9]{4})[/]{1}([0-9]{1,2})[/]{1}([0-9]{1,2})$");
    let flag0 = false,
        flag1 = false,
        flag2 = false;


    if (dataVal == "")
        flag0 = true;
    else {
        if (!re.test(dataVal)) {
            flag1 = true;
        } else {
            let d = Date.parse(dataVal);
            console.log(d);
            if (d = NaN) {
                flag2 = true;
                console.log(d == NaN);
            }
        }

    }
    if (1 == flag0)
        sp3.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>日期不能為空</a>";
    else if (1 == flag1)
        sp3.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>日期格式錯誤</a>";
    else if (1 == flag2)
        sp3.innerHTML = "<img src='Images/錯誤.png'><a style='color:red'>查無此日期</a>";
    else
        sp3.innerHTML = "<img src='Images/正確.png'><a style='color:green'>正確</a>";
}