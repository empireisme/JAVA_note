document.addEventListener("DOMContentLoaded", function () {
    let s = false;
    for (let i = 1; i <= 5; i++) {
        document.getElementById(`idimg${i}`).addEventListener("mouseover", function () { mouseover(i) }); //事件繫結，滑鼠滑入
        document.getElementById(`idimg${i}`).addEventListener("mouseout", mouseout); //事件繫結，滑鼠滑出
        document.getElementById(`idimg${i}`).addEventListener("click", function () { click(i) }); //事件繫結，滑鼠點擊
        document.getElementById(`idimg${i}`).addEventListener("dblclick", dblclick); //事件繫結，滑鼠雙點擊
    }

    function mouseover(j) {
        if (s == false) {
            document.getElementById(`idimg${j}`).src = "Images/chngstar.gif"
            for (let a = 1; a < j; a++) {
                document.getElementById(`idimg${a}`).src = "Images/chngstar.gif";
            }
            document.getElementById("score").innerHTML = (`評分...${j}顆星`)
        }
    }
    function mouseout() {
        if (s == false) {
            for (let a = 1; a <= 5; a++) {
                document.getElementById(`idimg${a}`).src = "Images/star.gif";
            }
            document.getElementById("score").innerHTML = (`評分...0顆星`)

        }
    }

    function click(j) {
        if (s == false) {
            document.getElementById(`idimg${j}`).src = "Images/chngstar.gif";
            for (let a = 1; a < j; a++) {
                document.getElementById(`idimg${a}`).src = "Images/chngstar.gif";
            }
            s = true
        }
    }

    function dblclick() {
        s = false;
        if (s == false) {
            document.getElementById(`idimg${j}`).src = "Images/star.gif";
        }

    }
});