document.write("<table>");      
for (var x = 2; x <= 9; x++)  
{  
    document.write("<td>");     
    for (var y = 1; y <= 9; y++)
    {  
        document.write(x+"*"+y+"="+x*y+"<br>");
    }                                                    
    document.write("</td>");  
}  
document.write("</table>");   