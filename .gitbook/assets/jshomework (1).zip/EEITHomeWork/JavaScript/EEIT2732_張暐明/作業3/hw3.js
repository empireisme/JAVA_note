document.addEventListener("DOMContentLoaded", function () {
    for (let stars = 0; stars < document.images.length; stars++) {
        document.images[stars].addEventListener("mouseover", mouseover);
        document.images[stars].addEventListener("mouseout", mouseout);
        document.images[stars].addEventListener("click", oneclick);
        document.images[stars].addEventListener("dblclick", dblclick);
    }   
});
let click;
let stars;
let prev = true;

function mouseover(e) {
    if (prev) {
        for (stars = "1"; stars <= e.currentTarget.id; stars++) {
            document.getElementById(stars).src = "image/shining.png";
        }
        document.getElementById("comment").innerText = (`評分為...${e.currentTarget.id}`)
    }
}

function mouseout(e) {
    if (prev) {
        for (let stars = "1"; stars <= e.currentTarget.id; stars++) {
            document.getElementById(stars).src = "image/empty.png";
        }
        document.getElementById("comment").innerText = (`請評論`)
    }
}
function oneclick(e) {
    if (prev) {
        click = e.currentTarget.id;
        document.getElementById("comment").innerText = (`你給${e.currentTarget.id}顆星`)
        prev = false;
    }
}
function dblclick(e) {
        if (click=e.currentTarget.id) {
        prev = true;
        mouseover(e);
        }
}