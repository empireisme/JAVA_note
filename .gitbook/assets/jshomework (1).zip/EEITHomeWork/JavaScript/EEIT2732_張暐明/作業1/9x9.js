document.write("<table>")
        var i = 2
        var rs;
while (i <= 9) {
    document.write("<td>")
    var j = 1;
    while (j <= 9) {
        rs = i * j;
        document.write(i + "x" + j + "=" + rs + "<br>");
        j++;
    }

    document.write("</td>")
    i++;
}
document.write(" </table>")