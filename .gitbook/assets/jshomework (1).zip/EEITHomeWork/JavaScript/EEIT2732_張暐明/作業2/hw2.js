window.onload = function () {
    document.getElementById("idName").onblur = checkName;
    document.getElementById("idPwd").onblur = checkPwd;
    document.getElementById("idDate").onblur = checkDate;
}
function checkName() {
    var inputName = document.getElementById("idName").value;
    var re = /\s/
    if (re.test(inputName)) {
        document.getElementById("rt1").innerHTML = "<img src='image/error.jpeg' color='red' class='im1' /> <span class='hint'>不可有空白</span>";
    }
    else {
        re = /^[^\u4e00-\u9fa5]+$/
        if (re.test(inputName)) {
            document.getElementById("rt1").innerHTML = "<img src='image/error.jpeg' color='red' class='im1'/> <span class='hint'>請輸入中文</span>";
        }
        else {
            if (inputName.length < 2) {
                document.getElementById("rt1").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>請輸入至少兩個中文字</span>";
            }
            else {
                document.getElementById("rt1").innerHTML = " <img src='image/correct.jpeg' class='im1'/> <span class='hint'>正確</span>";
               
            }
        }
    }
}

function checkPwd() {
    var inputPwd = document.getElementById("idPwd").value;
    var re = /\s/
    if (re.test(inputPwd)) {
        document.getElementById("rt2").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>不可有空白</span>";
    }
    else {
        re = /^[\u4e00-\u9fa5]+$/
        if (re.test(inputPwd)) {
            document.getElementById("rt2").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>不可輸入中文</span>";
        }
        else {
            if (inputPwd.length < 6) {
                document.getElementById("rt2").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>請輸入至少六個字數符號</span>";
            }
            else {
                re = /^[^\!\@\#\$\%\^\&\*]+$/
                if (re.test(inputPwd)) {
                    document.getElementById("rt2").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>需包含特殊符號!@#$%^&*</span>";
                }
                else {
                    re = /^[^0-9]+$/
                    if (re.test(inputPwd)) {
                        document.getElementById("rt2").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>需包含數字</span>";
                    }
                    else {
                        re = /^[^a-zA-Z]+$/
                        if (re.test(inputPwd)) {
                            document.getElementById("rt2").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>需包含英文</span>";
                        }
                        else {
                            document.getElementById("rt2").innerHTML = " <img src='image/correct.jpeg' class='im1'/> <span class='hint'>正確</span>";
                        }
                    }
                }
            }
        }
    }

}


function checkDate() {
    var inputDate = document.getElementById("idDate").value;
    var re = /\s/
    
    if (re.test(inputDate)) {
        document.getElementById("rt3").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>不可輸入空白</span>";
    }
    else {
        if (inputDate == "") {
            document.getElementById("rt3").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>請輸入日期</span>";
        }
        else {
            // re = /^[1-9]\d{3}\/(0[1-9]|1[0-2])\/(0[1-9]|[1-2][0-9]|3[0-1])$/
            re = /((^((1[8–9]\d{2})|([2–9]\d{3}))([-\/\._])(10|12|0?[13578])([-\/\._])(3[01]|[12][0–9]|0?[1–9])$)|(^((1[8–9]\d{2})|([2–9]\d{3}))([-\/\._])(11|0?[469])([-\/\._])(30|[12][0–9]|0?[1–9])$)|(^((1[8–9]\d{2})|([2–9]\d{3}))([-\/\._])(0?2)([-\/\._])(2[0–8]|1[0–9]|0?[1–9])$)|(^([2468][048]00)([-\/\._])(0?2)([-\/\._])(29)$)|(^([3579][26]00)([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][0][48])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2–9][0–9][0][48])([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][2468][048])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2–9][0–9][2468][048])([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][13579][26])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2–9][0–9][13579][26])([-\/\._])(0?2)([-\/\._])(29)$))/
            
            if (re.test(inputDate)) {
                document.getElementById("rt3").innerHTML = "<img src='image/correct.jpeg' class='im1'/><span class='hint'>正確</span> ";
            }
            else {
                document.getElementById("rt3").innerHTML = "<img src='image/error.jpeg' class='im1'/> <span class='hint'>日期錯誤</span>";
            }
        }
        
    }   
}