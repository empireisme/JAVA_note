document.addEventListener("DOMContentLoaded", function () {
    let imgbtns = document.querySelectorAll("img.imgbtn");
    let imgPlaybtns = document.querySelectorAll("img.imgPlay");
    let numClickFlag = imgbtns.item(0);
    let pauseFlag = false;
    let imgCount = 0;


    let imgs = ["AGEOFEMPIRES.jpg",
        "ASTRONEER.jpg",
        "Cozy_Grove.png",
        "DarkSouls.jpg",
        "Forza_Horizon.jpg",
        "HALO.jpg",
        "Monster_Hunter.jpg"];

    let hrefs = ["https://store.steampowered.com/app/813780/Age_of_Empires_II_Definitive_Edition/",
        "https://store.steampowered.com/app/361420/ASTRONEER/",
        "https://store.steampowered.com/app/1458100/Cozy_Grove/",
        "https://store.steampowered.com/app/374320/DARK_SOULS_III/",
        "https://store.steampowered.com/app/1293830/Forza_Horizon_4/",
        "https://store.steampowered.com/app/976730/Halo_The_Master_Chief_Collection/",
        "https://store.steampowered.com/app/582010/Monster_Hunter_World/"];
    // =============================================================================
    // 設置監聽
    for (let i = 0; i < imgbtns.length; i++) {
        imgbtns.item(i).addEventListener("click", imgbtnClick);
        imgbtns.item(i).addEventListener("mouseover", imgbtnMouseover);
        imgbtns.item(i).addEventListener("mouseout", imgbtnMouseout);
        imgbtns.item(i).addEventListener("mouseup", imgPlaybtnMouseup);
        imgbtns.item(i).addEventListener("mousedown", imgPlaybtnMousedown);
    }

    for (let i = 0; i < imgPlaybtns.length; i++) {
        imgPlaybtns.item(i).addEventListener("mouseup", imgPlaybtnMouseup);
        imgPlaybtns.item(i).addEventListener("mousedown", imgPlaybtnMousedown);
    }

    document.getElementById("idplaypause").addEventListener("click", imgPlaybtnPauseClick);
    document.getElementById("idleftArrow").addEventListener("click", imgLeftArrowClick);
    document.getElementById("idrightArrow").addEventListener("click", imgRightArrowClick);
    // =============================================================================
    // 監聽事件呼叫函數
    function imgbtnClick() {//點擊數字變更圖片
        document.getElementById("idimg").src = "img/" + imgs[index(this, imgbtns)];
        document.getElementById("idhref").href = hrefs[index(this, imgbtns)];
        this.style.opacity = 1;
        numClickFlag = this;
        imgCount = index(this, imgbtns);

        pause();
        // console.log(index(this, imgbtns));
        // console.log(imgs[index(this, imgbtns)]);

        for (let imgbtn of imgbtns) {
            if (numClickFlag != imgbtn)
                imgbtn.style.opacity = 0.5;
        }
    }
    // ===========================================
    // 尋找事件物件在NodeList中的位置
    function index(el, imgbtns) {
        for (let i = 0; i < imgbtns.length; i++) {
            if (el == imgbtns.item(i))
                return i;
        }
    }
    // ===========================================
    // 監聽事件呼叫函數
    function imgbtnMouseover() {//移到數字按鈕上
        this.style.opacity = 1;
    }

    function imgbtnMouseout() {//移開數字按鈕
        if (imgCount == index(this, imgbtns))
            return;
        this.style.opacity = 0.5;
    }

    function imgPlaybtnMousedown() {//按下圖片變淡
        this.style.opacity = 0.5;
    }

    function imgPlaybtnMouseup() {//放開圖片變亮
        this.style.opacity = 1;
    }

    function imgPlaybtnPauseClick() {
        if (!pauseFlag) {
            clearInterval(intervalID);
            this.src = "play.png";
            pauseFlag = true;
        }
        else {
            play(this);
        }
    }

    function imgLeftArrowClick() {//向左播放
        pause();
        if (imgCount == 0) {
            imgCount = imgs.length;
        }
        imgCount--;
        
        changeImg_href()
    }

    function imgRightArrowClick() {//向右播放
        pause();
        imgCount++;
        if (imgCount == imgs.length) {
            imgCount = 0;
        }
        
        changeImg_href()
    }

    let intervalID = setInterval(function () {//先啟動自動播放
        imgCount++;
        if (imgCount == imgs.length) {
            imgCount = 0;
        }
        changeImg_href();
    }, 2000);
    // ===================================================================
    // 播放
    function play(el) {
        if (pauseFlag) {
            // document.getElementById("idplaypause").src = "pause.png"
            el.src = "pause.png";
            intervalID = setInterval(function () {
                imgCount++;
                if (imgCount == imgs.length) {
                    imgCount = 0;
                }
                changeImg_href();
            }, 2000);
            pauseFlag = false;
        }

    }
    // 暫停
    function pause() {
        if (!pauseFlag) {
            document.getElementById("idplaypause").src = "play.png";
            clearInterval(intervalID);
            pauseFlag = true;
        }

    }

    // ===================================================================
    //變更圖片及網址
    function changeImg_href() {

        console.log("img/" + imgs[imgCount]);
        document.getElementById("idimg").src = "img/" + imgs[imgCount];
        document.getElementById("idhref").href = hrefs[imgCount];
        imgbtns.item(imgCount).style.opacity = 1;
        console.log(imgCount);

        for (let i = 0; i < imgbtns.length; i++) {
            if (imgCount != i)
                imgbtns.item(i).style.opacity = 0.5;
        }



    }


})