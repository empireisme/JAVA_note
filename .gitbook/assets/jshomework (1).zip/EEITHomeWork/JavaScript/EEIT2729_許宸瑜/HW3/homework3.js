document.addEventListener("DOMContentLoaded", function () {
    let star1 = document.getElementById("idstar1");
    let star2 = document.getElementById("idstar2");
    let star3 = document.getElementById("idstar3");
    let star4 = document.getElementById("idstar4");
    let star5 = document.getElementById("idstar5");

    let starArr = [star1, star2, star3, star4, star5];
    let clickFlag = false;

    for (let i = 0; i < starArr.length; i++) {
        starArr[i].addEventListener("click", function () { clickStar(i + 1) });
        starArr[i].addEventListener("dblclick", resetStar);

        starArr[i].addEventListener("mouseover", function () { mouseover(i + 1) });
        starArr[i].addEventListener("mouseout", mouseout);

    }

    function clickStar(starNum) {
        if (!clickFlag) {
            for (let i = 0; i < starNum; i++) {
                starArr[i].style.opacity = 1;
            }
        }
        document.getElementById("idScorespan").innerHTML = `您給${starNum}分`;
        clickFlag = true;
    }

    function resetStar() {
        clickFlag = false;
        for (let i = 0; i < starArr.length; i++) {
            starArr[i].style.opacity = 0.5;
        }
        document.getElementById("idScorespan").innerHTML = `評分為...0`;
    }

    function mouseover(starNum) {
        if (!clickFlag) {
            for (let i = 0; i < starNum; i++) {
                starArr[i].style.opacity = 1;
            }
            document.getElementById("idScorespan").innerHTML = `評分為...${starNum}`;
        }
    }

    function mouseout() {
        if (!clickFlag) {
            for (let i = 0; i < starArr.length; i++) {
                starArr[i].style.opacity = 0.5;
            }
            document.getElementById("idScorespan").innerHTML = `評分為...0`;
        }
    }
});


