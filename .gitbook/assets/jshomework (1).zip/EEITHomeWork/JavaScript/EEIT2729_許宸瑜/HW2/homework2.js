function checkName() {
    let theNameObj = document.getElementById("idName");
    let theNameObjVal = theNameObj.value;
    let sp = document.getElementById("idspname")
    let theNameObjValLen = theNameObjVal.length;

    if (theNameObjVal == "")
        sp.innerHTML = "<img src=\"cross.PNG\">不可空白";
    else if (theNameObjValLen < 2)
        sp.innerHTML = "<img src=\"cross.PNG\">至少兩個字以上";
    else if (!isNameChecked(theNameObjVal))
        sp.innerHTML = "<img src=\"cross.PNG\">必須全部為中文字";
    else
        sp.innerHTML = "<img src=\"tick.PNG\">正確";
}

function checkPwd() {
    //取得ipwd元素
    let thePwdObj = document.getElementById("idPwd");
    //取得ipwd元素值
    let thePwdObjVal = thePwdObj.value;
    //判斷元素值是否為空，密碼長度大於6
    //如果長度大於6，判斷是否包含字母、數字、特殊符號
    let sp = document.getElementById("idsppwd");
    let thePwdObjValLen = thePwdObjVal.length;
    if (thePwdObjVal == "")
        sp.innerHTML = "<img src=\"cross.PNG\">不可空白"
    else if (thePwdObjValLen < 6 || !isPwdChecked(thePwdObjVal))
        sp.innerHTML = "<img src=\"cross.PNG\">至少6個字且必須包含英數字、特殊字元[!@#$%^&*]";
    else
        sp.innerHTML = "<img src=\"tick.PNG\">正確";
}

function checkDate() {
    let theDateObj = document.getElementById("idDate");
    let theDateObjVal = theDateObj.value;
    let sp = document.getElementById("idspdate")

    if (!isDateExit(theDateObjVal)) 
        sp.innerHTML = "<img src=\"cross.PNG\">無此日期";
    else
        sp.innerHTML = "<img src=\"tick.PNG\">正確";
}
/*===========================================================================*/

function isPwdChecked(thePwdObjVal) {//至少有英文、數字、特殊字
    let flagAZ = false;
    let flag09 = false;
    let flagsp = false;
    let spchar = ["!", "@", "#", "$", "%", "^", "&", "*"];

    for (let i = 0; i < thePwdObjVal.length; i++) {//有英文，通過
        let ch = (thePwdObjVal.charAt(i)).toUpperCase();
        if (ch >= "A" && ch <= "Z")
            flagAZ = true;
    }

    for (let i = 0; i < thePwdObjVal.length; i++) {//有數字，通過
        let ch = thePwdObjVal.charAt(i);
        if (ch >= "0" && ch <= "9")
            flag09 = true;
    }

    for (let i = 0; i < spchar.length; i++) {//有特殊字，通過
        if (thePwdObjVal.includes(spchar[i])) {
            flagsp = true;
        }
    }


    if (flagAZ && flag09 && flagsp)
        return true;
    else
        return false;
}

function isNameChecked(theNameObjVal) {//只能中文字

    for (let i = 0; i < theNameObjVal.length; i++) {//當有一個字非中文，不通過
        let ch = theNameObjVal.charCodeAt(i);
        if (ch < 0x4e00 || ch > 0x9fff)
            return false;
    }
    return true;
}

function isDateExit(theDateObjVal) {
    let dateObj = theDateObjVal.split('/');

    let limitDate = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    let theYear = parseInt(dateObj[0]);
    let theMonth = parseInt(dateObj[1]);
    let theDate = parseInt(dateObj[2]);

    let isLeap = new Date(theYear, 1, 29).getDate() === 29;//判斷是否閏年

    if (isLeap) {
        limitDate[1] = 29;
    }

    return theDate <= limitDate[theMonth - 1];
}