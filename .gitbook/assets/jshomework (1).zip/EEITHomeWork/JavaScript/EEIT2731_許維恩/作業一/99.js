document.write("<table>");
document.write("<th colspan=8>九九乘法表</th>");
for (let i = 1; i < 10; i++) {
    document.write("<tr>");
    for (let j = 2; j < 10; j++) {
    if(i*j<10){
        document.write("<td>" + j + "*" + i + "=0" + i * j + "</td>");
    }else{
        document.write("<td>" + j + "*" + i + "=" + i * j + "</td>");
    }
    }
    document.write("</tr>");
}
document.write("</table>")