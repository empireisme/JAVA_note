for (let i = 0; i < 5; i++) {
    document.getElementById(`star${i + 1}`).onmouseover = mouseOver;
    document.getElementById(`star${i + 1}`).onmouseout = mouseOut;
    document.getElementById(`star${i + 1}`).onclick = onClick;
    document.getElementById(`star${i + 1}`).ondblclick = onDblclick;
}
let starNum;
function mouseOver() {
    if (this.className.length <= 3) {
        starNum = this.id.charAt(4);
        for (let i = 0; i < starNum; i++) {
            document.getElementById(`star${i + 1}`).className = "on";
            document.getElementById("note").innerHTML = `評分為...${starNum}`;
        }
    }
}

function mouseOut() {
    if (this.className.length <= 3) {
        for (let i = 0; i < starNum; i++) {
            document.getElementById(`star${i + 1}`).className = "off";
        }
        document.getElementById("note").innerHTML = ``;
    }
}

function onClick() {
    if (this.className.length <= 3) {
        document.getElementById("note").innerHTML = `你給了${starNum}顆星星`;
        for (let i = 0; i < 5; i++) {
            document.getElementById(`star${i + 1}`).className += " click";
        }
    }


}
function onDblclick() {
    for (let i = 0; i < 5; i++) {
        document.getElementById(`star${i + 1}`).className = "off";
    }
}