// ---------------- 名字 ----------------
function checkname() {
    let nameObj = document.getElementById("name01");
    let msid = nameObj.value;
    let sp = document.getElementById("idsp");
    let idlen = msid.length;
    let emp = false;
    let mssp = true;
    let lench = false;
    if (idlen == "") {
        emp = true;
    } else if (idlen < 2)
        lench = true;
    else {
        for (let i = 0; i < idlen; i++) {
            let ch = msid.charAt(i);
            console.log(ch);
            if (ch < "\u4E00" || ch > "\u9FFF") {
                mssp = false;
                console.log(mssp);
                break;
            }
        }
    }
    if (emp == true) {
        sp.innerHTML
        sp.innerHTML = "<span class='errPic'><img src='images/no.jpg'>不可為空白</span>";
    }
    else if (lench == true) {
        sp.innerHTML = "<span class='errPic'><img src='images/no.jpg'>文字長度錯誤</span>";
    }
    else if (mssp == true) {
        sp.innerHTML = "<span class='yesPic'><img src='images/yes.jpg'>正確</span>";
    } else {
        sp.innerHTML = "<span class='errPic'><img src='images/no.jpg'>必須全為中文</span>";
    }
}

//================ 特殊字元 ================
let totalSymbol = "!@#$%^&*";
let symbolArr = new Array();
symbolArr = totalSymbol.split("");
let symbolLen = symbolArr.length;
function chechSymbol(x) {
    let isMatch = false;
    for (let i = 0; i < symbolLen; i++) {
        if (x == symbolArr[i]) {
            isMatch = true;
            break;
        }
    }
    return isMatch;
}

//================ 密碼 ================
let getpwd = document.getElementById("password");
getpwd.onblur = function () {
    let pwsp = document.getElementById("pssp");
    let pwdValue = getpwd.value.toUpperCase();
    let pwdLength = true;
    let isEmpty, isEnglish, isSymbol, isNum = false;
    if (pwdValue == "") {
        isEmpty = true;
    } else if (pwdValue.length < 6) {
        pwdLength = false;
    } else {
        for (let i = 0; i < pwdValue.length; i++) {
            let ch = pwdValue.charAt(i);
            if (ch >= "A" && ch <= "Z") {
                isEnglish = true;
            } else if (ch >= 0 && ch <= 9) {
                isNum = true;
            } else {
                let x = chechSymbol(ch);
                if (x == true) {
                    isSymbol = x;
                }
            }
            if (isEnglish == true && isSymbol == true && isNum == true) {
                break;
            }
        }
    }
    if (isEmpty == true) {
        pwsp.innerHTML = "<span class='errPic'><img src='images/no.jpg'>不可為空白</span>";
    } else if (isEnglish == true && isSymbol == true && isNum == true) {
        pwsp.innerHTML = "<span class='yesPic'><img src='images/yes.jpg'>正確</span>";
    } else if (pwdLength == false) {
        pwsp.innerHTML = "<span class='errPic'><img src='images/no.jpg'>密碼長度錯誤</span>";
    } else {
        pwsp.innerHTML = "<span class='errPic'><img src='images/no.jpg'>缺少英文、數字或特殊字元</span>";
    }
};

//================日期================
let dateObj = document.getElementById("date");
dateObj.onblur = function () {
    let dateValue = dateObj.value;
    let dateArr = new Array();
    dateArr = dateValue.split("/");
    let arrlen = dateArr.length;
    console.log(arrlen);
    let chFormat = true;
    let chDate = true;
    let d = new Date(`${dateArr[0]}-${dateArr[1]}-${dateArr[2]}`);
    let getDa = d.getDate();
    if (arrlen != 3) {
        chFormat = false;
    } else if (dateArr[0] < 1 || dateArr[0] > 9999 || dateArr[1] < 1 || dateArr[1] > 12 || dateArr[2] < 1 || dateArr[2] > 31) {
        chDate = false;
    } else if (dateArr[2] != getDa) {
        chDate = false;
    }

    if (chFormat == false) {
        datesp.innerHTML = "<span class='errPic'><img src='images/no.jpg'>格式錯誤缺少\"/\"</span>";
    } else if (chDate == false) {
        datesp.innerHTML = "<span class='errPic'><img src='images/no.jpg'>無此日期</span>";
    } else {
        datesp.innerHTML = "<span class='yesPic'><img src='images/yes.jpg'>正確</span>";
    }
};