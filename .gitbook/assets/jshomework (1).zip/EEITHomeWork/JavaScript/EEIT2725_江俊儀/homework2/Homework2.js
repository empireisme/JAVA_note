document.getElementById("idName").onblur = checkName;
function checkName() {
    
    let theNameObj = document.getElementById("idName");
    console.log(theNameObj);
    
    let theNameObjVal = theNameObj.value;
    console.log(theNameObjVal);
    console.log(typeof theNameObjVal);

    let sp = document.getElementById("idsp1");
    let theNameObjValLen = theNameObjVal.length;
    let flag1 = false, flag2 = false, flag3 = false;

    if (theNameObjVal == "")
        sp.innerHTML = "<img src='Images/error.png'> 請輸入姓名!";
    else if (theNameObjValLen >= 2) {
        // sp.innerHTML=">=2";
        for (let i = 0; i < theNameObjValLen; i++) {
            let ch = theNameObjVal.charCodeAt(i);
            if (ch >= 0x4E00 && ch <= 0x9FFF)
                flag1 = true;
            else {
                flag1 = false;
                break;
            }
        }
        if (flag1)
            sp.innerHTML = "<img src='Images/correct.png'> 輸入正確!";
        else
            sp.innerHTML = "<img src='Images/error.png'> 必須全部為中文字!";
    } else {
        sp.innerHTML = "<img src='Images/error.png'> 至少2個字以上!";
    }
}

document.getElementById("idPwd").onblur = checkPwd;
function checkPwd() {
    //取得idPwd元素
    let thePwdObj = document.getElementById("idPwd");
    console.log(thePwdObj);
    //取得idPwd元素值
    let thePwdObjVal = thePwdObj.value;
    console.log(thePwdObjVal);
    console.log(typeof thePwdObjVal);

    //判斷元素值是否為空白，密碼長度是否大於6
    //如果長度是否大於6，判斷是否包含字母、數字、特殊符號
    let sp = document.getElementById("idsp2");
    let thePwdObjValLen = thePwdObjVal.length;
    let flag1 = false, flag2 = false, flag3 = false;

    if (thePwdObjVal == "")
        sp.innerHTML = "<img src='Images/error.png'> 請輸入密碼!";
    else if (thePwdObjValLen >= 6) {
        // sp.innerHTML=">=6";
        for (let i = 0; i < thePwdObjValLen; i++) {
            let ch = thePwdObjVal.charAt(i).toUpperCase();
            // let ch = thePwdObjVal.charAt(i);
            if (ch >= "A" && ch <= "Z")
                flag1 = true;
            else if (ch >= "0" && ch <= "9")
                flag2 = true;
            // else if (ch1 = /[!@#\$%\^&\*]{1,}/)
            else if (ch =="!" || ch =="@" || ch =="#" || ch =="$" ||
                    ch =="%" || ch =="^" || ch =="&" || ch =="*")
                flag3 = true;
            if (flag1 && flag2 && flag3) break;
        }
        if (flag1 && flag2 && flag3)
            sp.innerHTML = "<img src='Images/correct.png'> 輸入正確!";
        else
            sp.innerHTML = "<img src='Images/error.png'> 必須包含英數字、特殊字元[!@#$%^&*] !";
    } else {
        sp.innerHTML = "<img src='Images/error.png'> 至少6個字以上!";
    }
}

document.getElementById("idDate").onblur = checkDate;
function checkDate() {
    let theDateObj = document.getElementById("idDate");
    console.log(theDateObj);

    let theDateObjVal = theDateObj.value;
    console.log(theDateObjVal);
    console.log(theDateObjVal.length);
    console.log(typeof theDateObjVal);

    let sp = document.getElementById("idsp3");
    let theDateObjValLen = theDateObjVal.length;

    if(theDateObjVal == "")
        sp.innerHTML="<img src='Images/error.png'>請輸入日期!";
    else if(theDateObjValLen==10){
        let theDateEle=theDateObjVal.split("/");
        
        let dateObj=new Date(theDateEle[0],theDateEle[1]-1,theDateEle[2]);
        
        let yyObj=dateObj.getFullYear();
        let mmObj=dateObj.getMonth()+1;
        let ddObj=dateObj.getDate();

        let yyStr=yyObj.toString();
        let mmStr=mmObj.toString();
        let ddStr=ddObj.toString();

        let yyStr0;
        let mmStr0;
        let ddStr0;

        if(yyObj<1000){
            yyStr0="0"+yyStr;
            if(yyObj<100){
                yyStr0="00"+yyStr;
                if(yyObj<10)
                    yyStr0="000"+yyStr;
            }
        }
        if(mmObj<10){
            mmStr0="0"+mmStr;
        }

        if(ddObj<10){
            ddStr0="0"+ddStr;
        }

        if(theDateEle[0] == yyStr ||theDateEle[0]== yyStr0){
            if(theDateEle[1]== mmStr ||theDateEle[1]== mmStr0)
                if(theDateEle[2]== ddStr ||theDateEle[2]== ddStr0)
                    sp.innerHTML="<img src='Images/correct.png'>輸入正確!";
                else
                    sp.innerHTML="<img src='Images/error.png'>請輸入正確日期!";
            else
                sp.innerHTML="<img src='Images/error.png'>請輸入正確日期!";
        }else
            sp.innerHTML="<img src='Images/error.png'>請輸入正確日期!";    
        }   

    else {
        sp.innerHTML = "<img src='Images/error.png'> 日期格式需正確!";
    }
    

}