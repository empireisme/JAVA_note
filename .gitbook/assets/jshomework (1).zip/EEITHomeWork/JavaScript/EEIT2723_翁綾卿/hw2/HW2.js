window.onload = function () {
document.getElementById("name").addEventListener("blur", checkName);
function checkName() {
    let nameObj = document.getElementById("name");
    let nameObjVal = nameObj.value;
    let nameSp = document.getElementById("nameSp");
    let nameObjValLen = nameObjVal.length;
    reChi = /[^\u4E00-\u9FFF]/;

    if (nameObjVal == "") {
        nameSp.innerHTML = "<img src=images/error.png>此欄位不可空白";
    } else if (nameObjValLen >= 2) {
        if (reChi.test(nameObjVal)) {
            nameSp.innerHTML = "<img src=images/error.png>必須全部為中文字";
        } else {
            nameSp.innerHTML = "<img src=images/check.png>";
        }
    } else {
        nameSp.innerHTML = "<img src=images/error.png>至少兩個字以上";
    }
}


document.getElementById("pwd").addEventListener("blur", checkPwd);
function checkPwd() {
    let pwdObj = document.getElementById("pwd");
    let pwdObjVal = pwdObj.value;
    let pwdSp = document.getElementById("pwdSp");
    let pwdObjValLen = pwdObjVal.length;
    reEng = /[A-Za-z]/;
    reNum = /[0-9]/;
    reSpe = /[\!\@\#\$\%\^\&\*]/;

    if (pwdObjVal == "") {
        pwdSp.innerHTML = "<img src=images/error.png>此欄位不可空白";
    } else if (pwdObjValLen >= 6) {
        if (reEng.test(pwdObjVal) && reNum.test(pwdObjVal) && reSpe.test(pwdObjVal)) {
            pwdSp.innerHTML = "<img src=images/check.png>";
        } else {
            pwdSp.innerHTML = "<img src=images/error.png>必須包含英數字、特殊字元[!@#$%^&*]";
        }
    } else {
        pwdSp.innerHTML = "<img src=images/error.png>密碼長度不足";
    }
}


document.getElementById("date").addEventListener("blur", checkDate);
function checkDate() {
    let dateObj = document.getElementById("date");
    let dateObjVal = dateObj.value;
    let dateSp = document.getElementById("dateSp");
    reDate = /[0-9]{4}\/[0-9]{2}\/[0-9]{2}/;

    if (reDate.test(dateObjVal)) {
        let dateObjValSpl = dateObjVal.split("/");
        let year = parseInt(dateObjValSpl[0],10);
        let month = parseInt(dateObjValSpl[1],10);
        let day = parseInt(dateObjValSpl[2],10);
        if (dateObjVal == "") {
            dateSp.innerHTML = "<img src=images/error.png>此欄位不可空白";
        } else if (year > 0 && month > 0 && month <= 12 && day > 0 && day <= 31) {
            if (month == 2) {
                if (year % 4 == 0) {
                    if (year % 100 == 0) {
                        if (year % 400 == 0) {
                            dateSp.innerHTML = "<img src=images/correct.png>";
                        } else {
                            if (day > 28) {
                                dateSp.innerHTML = "<img src=images/error.png>日期錯誤";
                            } else {
                                dateSp.innerHTML = "<img src=images/correct.png>";
                            }
                        }
                    } else {
                        dateSp.innerHTML = "<img src=images/correct.png>";
                    }
                } else {
                    if (day > 28) {
                        dateSp.innerHTML = "<img src=images/error.png>日期錯誤";
                    } else {
                        dateSp.innerHTML = "<img src=images/correct.png>";
                    }
                }
            } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                if (day > 30) {
                    dateSp.innerHTML = "<img src=images/error.png>日期錯誤";
                } else {
                    dateSp.innerHTML = "<img src=images/correct.png>";
                }
            } else {
                if (day > 31) {
                    dateSp.innerHTML = "<img src=images/error.png>日期錯誤";
                } else {
                    dateSp.innerHTML = "<img src=images/correct.png>";
                }
            }
        } else {
            dateSp.innerHTML = "<img src=images/error.png>日期錯誤";
        }
    } else {
        dateSp.innerHTML = "<img src=images/error.png>日期錯誤";
    }
}
}