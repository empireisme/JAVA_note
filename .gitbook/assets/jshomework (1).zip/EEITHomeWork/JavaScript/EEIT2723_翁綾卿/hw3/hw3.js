let i;
document.addEventListener("DOMContentLoaded", function () {
    for (i = 0; i < document.images.length; i++) {  //簡化5個星星5x4事件
        document.images[i].addEventListener("mouseover", mouseover);
        document.images[i].addEventListener("mouseout", mouseout);
        document.images[i].addEventListener("mousedown", click);
        document.images[i].addEventListener("dblclick", dblclick);
    }
});
let move = true;
function mouseover() {
    if (move) {  
        for (var i = "1"; i <= this.id; i++) { //事件連續觸發
            document.getElementById(i).src = "images/changstar.gif";
        }
        document.getElementById("score").innerHTML = `${i - 1}分`;
    }
    document.getElementById("score1").innerHTML = "";
}
function mouseout() {
    if (move) {
        for (var i = "1"; i <= this.id; i++) {
            document.getElementById(i).src = "images/star.gif";
        }
        document.getElementById("score").innerHTML = "0分";
    }
    document.getElementById("score1").innerHTML = "";
}
function click() {
    if (move) {   //星星定格
        document.getElementById("score").innerHTML = `您給了${this.id}分`;
        move = false;
        oneClick = this.id  ;     
    }
}

function dblclick() {
    move = true;
    document.getElementById("score").innerHTML = "";
    document.getElementById("score1").innerHTML = "請重設";
    action = true;
    
    for (var i = 0; i < oneClick; i++) {  //事件觸發己次做幾次
        document.images[i].src = "images/star.gif";
        
    }
    

}