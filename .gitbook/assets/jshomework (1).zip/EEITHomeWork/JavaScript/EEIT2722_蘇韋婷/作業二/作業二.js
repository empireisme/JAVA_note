function checkAcc(){
    let theAccObj=document.getElementById("account1");
    let theAccObjVal=theAccObj.value;
    let sa=document.getElementById("idac");
    let theAccObjValLen=theAccObjVal.length;
    let flag4=false;

    if(theAccObjVal=="")
        sa.innerHTML="<img src='Images/error2.png'>您必須輸入姓名"; 
    else if(theAccObjValLen>=2){
        for(let j=0;j<theAccObjValLen;j++){
            let acc=theAccObjVal.charCodeAt(j);
            if(acc>=0x4e00 && acc<=0x9fff)
                flag4=true; 
            if (flag4) break;
        }
        if(flag4)
            sa.innerHTML="<img src='Images/correct.png'>正確";
        else
            sa.innerHTML="<img src='Images/error2.png'>輸入不正確，請重新輸入";
    }else{
        sa.innerHTML="<img src='Images/error2.png'>帳號長度必須大於2";
    }
}

function checkPwd(){    
    let thePwdObj=document.getElementById("pwd1");
    let thePwdObjVal=thePwdObj.value;
    let sp=document.getElementById("idsp");
    let thePwdObjValLen=thePwdObjVal.length;
    let flag1=false,flag2=false,flag3=false;

    if(thePwdObjVal=="")
        sp.innerHTML="<img src='Images/error2.png'>您必須輸入密碼"; 
    else if(thePwdObjValLen>=6){
        for(let i=0;i<thePwdObjValLen;i++){
            let ch=thePwdObjVal.charAt(i).toUpperCase();
            let pwch= ["!", "@", "#", "$", "%", "^", "&", "*"];
            if(ch>="A" && ch<="Z")
                flag1=true;
            else if(ch>="0" && ch<="9")
                flag2=true;
            else if(thePwdObjVal.includes(pwch[i]))
                flag3=true;
            if(flag1 && flag2 && flag3) break;
        }
        if(flag1 && flag2 && flag3)
            sp.innerHTML="<img src='Images/correct.png'>正確";
        else
            sp.innerHTML="<img src='Images/error2.png'>輸入不正確，需包含6個英數字及特殊符號";
    }else{
        sp.innerHTML="<img src='Images/error2.png'>密碼長度必須大於6";
    }
}

function checkDate(){
    let theDateObj=document.getElementById("date1");
    let theDateObjVal=theDateObj.value;
    let sp=document.getElementById("idda");
    
    if(theDateObjVal=="")
        sp.innerHTML="<img src='Images/error2.png'>日期不正確";
    else if(!checkDateCorrect)
        sp.innerHTML="<img src='Images/error2.png'>日期不正確";
    else
        sp.innerHTML="<img src='Images/correct.png'>正確";

    function checkDateCorrect(){        
        let limitInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        let theYear = parseInt(dateObj[0])
        let theMonth = parseInt(dateObj[1])
        let theDay = parseInt(dateObj[2])
        let isLeap = new Date(theYear, 1, 29).getDate() === 29
        
        if(isLeap){
            limitInMonth[1] = 29;    
        }
            return theDay <= limitInMonth[theMonth - 1];
    }   
}
