document.write("<table class=st>")
            document.write("<tr>")
            for(let j=2;j<10;j++){
                document.write("<td>")
            for(let i=1;i<10;i++){
                document.write(j+"*"+i+"="+i*j+"&emsp;")
                document.write("<br>")
            }
            

        }