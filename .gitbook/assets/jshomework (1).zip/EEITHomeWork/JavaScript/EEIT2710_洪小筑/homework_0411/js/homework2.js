
document.getElementById("idName").onblur=checkName;
function checkName() {
    //取得元素值
    let theNameObjVal = document.getElementById("idName").value;
    //建立RegExp物件語法 2(literal)
    let re = /^.+[\u4e00-\u9fff]$/;
    //判斷元素值是否為空白，密碼長度是否大等於2
    //如果長度是否大於2，判斷是否是中文字
    let sp = document.getElementById("idspName");
    let theNameObjValLen = theNameObjVal.length;
    if (theNameObjVal == "")
        sp.innerHTML = "姓名不可空白";
    else if (theNameObjValLen>=2) {
        if (re.test(theNameObjVal))
            sp.innerHTML = "正確";
        else
            sp.innerHTML = "姓名必須全部是中文字";
    } else {
        sp.innerHTML = "姓名至少2個字"
    }
 
}


document.getElementById("idPwd").onblur=checkPwd;
        function checkPwd(){
            //取得idPwd元素
            let thePwdObj=document.getElementById("idPwd");
            console.log(thePwdObj);
            //取得idPwd元素值
            let thePwdObjVal=thePwdObj.value;
            console.log(thePwdObjVal);
            console.log(typeof thePwdObjVal);

            //判斷元素值是否為空白，密碼長度是否大於6
            //如果長度是否大於6，判斷是否包含字母、數字、特殊符號
            let sp=document.getElementById("idsp");
            let thePwdObjValLen=thePwdObjVal.length;
            let flag1=false,flag2=false,flag3=false;

            if(thePwdObjVal=="")
                sp.innerHTML="<img src='Images/error.png'>you must enter";
            else if(thePwdObjValLen>=6){
                // sp.innerHTML=">=6";
                for(let i=0;i<thePwdObjValLen;i++){
                    let ch=thePwdObjVal.charAt(i).toUpperCase();
                    if(ch>="A" && ch<="Z")
                        flag1=true;
                    else if(ch>="0" && ch<="9")
                        flag2=true;
                    if(flag1 && flag2) break;
                }
                if(flag1 && flag2)
                    sp.innerHTML="correct";
                else
                    sp.innerHTML="<img src='Images/error.png'>incorrect";
            }else{
                sp.innerHTML="<img src='Images/error.png'>Password length must be greater than 6";
            }     
        }    
document.getElementById("dateid").onblur=isExistDate;      
function isExistDate(dateStr) {
        let theDateObj = document.getElementById("dateid");
        let theDateObjVal = theDateObj.value;
        let sp = document.getElementById("dateidsp")
 
        if (!isDateExit(theDateObjVal)) 
        sp.innerHTML = "請輸入正確日期";
        else
        sp.innerHTML = "正確";
    }
function isDateExit(theDateObjVal) {
        let dateObj = theDateObjVal.split('/');
 
        let limitDate = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
 
        let theYear = parseInt(dateObj[0]);
        let theMonth = parseInt(dateObj[1]);
        let theDate = parseInt(dateObj[2]);
 
        let isLeap = new Date(theYear, 1, 29).getDate() === 29;//判斷是否閏年
 
        if (isLeap) {
            limitDate[1] = 29;
        }
 
    return theDate <= limitDate[theMonth - 1];
    }


  