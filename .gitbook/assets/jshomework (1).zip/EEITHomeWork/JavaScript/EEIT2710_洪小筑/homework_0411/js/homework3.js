document.addEventListener("DOMContentLoaded", function() {
    let pic = document.images;
    let piclen = pic.length;
    for (let i = 0; i < piclen; i++) {
        pic[i].addEventListener("mouseout", mouseout);
        pic[i].addEventListener("mouseover", mouseover);
        pic[i].addEventListener("click", Click);
    }
    document.addEventListener("dblclick", clean);
});

function mouseover() {
    let pic = document.images;
    for (let i = 0; i < this.id.substr(5); i++) {
        pic[i].src = "Images/chngstar.gif";
        document.getElementById("score").innerHTML = `現在您給了${i + 1}顆星囉`;
    }
}
function mouseout() {
    let pic = document.images;
    for (let i = 0; i < this.id.substr(5); i++) {
        pic[i].src = "Images/star.gif";
        document.getElementById("score").innerHTML = "";
    }
}

function Click() {
    let pic = document.images;
    for (let i = 0; i < this.id.substr(5); i++) {
        pic[i].src = "Images/chngstar.gif";
        document.getElementById("score").innerHTML = `謝謝您給予${i+1}星評價，期待您再次使用本服務！！！！`;
    }
    let piclen = pic.length;
    for (let i = 0; i < piclen; i++) {
        pic[i].removeEventListener("mouseout", mouseout);
        pic[i].removeEventListener("mouseover", mouseover);
        pic[i].removeEventListener("click", Click);
    }
}

function clean() {
    let pic = document.images;
    let piclen = pic.length;
    document.getElementById("score").innerHTML = "";
    for (let i = 0; i < piclen; i++) {
        pic[i].src = "Images/star.gif";
        pic[i].addEventListener("mouseout", mouseout);
        pic[i].addEventListener("mouseover", mouseover);
        pic[i].addEventListener("click", Click);
    }
    }