document.addEventListener("DOMContentLoaded", function () {
    let pic = document.images;
    let piclen = pic.length;
    for (let i = 0; i < piclen; i++) {
        pic[i].addEventListener("mouseout", mouseout);
        pic[i].addEventListener("mouseover", mouseover);
        pic[i].addEventListener("click", Click);
        pic[i].addEventListener("dblclick", clean);
    }  
});

function mouseover() {
    let pic = document.images;
    for (let i = 0; i < this.id.substr(5); i++) {
        pic[i].src = "image/chngstar.jpg";
        document.getElementById("score").innerHTML = `~開始評分囉，目前${i + 1}顆星~`;
    }
}
function mouseout() {
    let pic = document.images;
    for (let i = 0; i < this.id.substr(5); i++) {
        pic[i].src = "image/star.jpg";
        document.getElementById("score").innerHTML = "";
    }
}
function Click() {
    let pic = document.images;
    for (let i = 0; i < this.id.substr(5); i++) {
        pic[i].src = "image/chngstar.jpg";
        document.getElementById("score").innerHTML = `~恭喜，獲得${i + 1}顆星!!!! <img src="image/good.jpg"> (雙擊星星可重新評分)~`;
    }
    let piclen = pic.length;
    for (let i = 0; i < piclen; i++) {
        pic[i].removeEventListener("mouseout", mouseout); //固定click效果，不執行mouseout效果
        pic[i].removeEventListener("mouseover", mouseover); //固定click效果，不執行mouseover效果
        pic[i].removeEventListener("click", Click); 
    }
}
function clean() {
    let pic = document.images;
    let piclen = pic.length;
    document.getElementById("score").innerHTML = "";
    for (let i = 0; i < piclen; i++) {
        pic[i].src = "image/star.jpg";
        pic[i].addEventListener("mouseover", mouseover); //再重複進行mouseover
        pic[i].addEventListener("mouseout", mouseout); //重複再進行mouseout
        pic[i].addEventListener("click", Click); //再重複進行click
    }
}