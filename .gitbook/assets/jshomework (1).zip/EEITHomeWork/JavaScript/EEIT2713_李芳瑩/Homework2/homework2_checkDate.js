function checkDate() {
    //取得idDate元素
    let theDateObj = document.getElementById("idDate");
    // console.log(theDateObj);
    //取得idDate元素值
    let theDateObjVal = theDateObj.value;
    console.log(theDateObjVal);
    console.log(`typeof=${typeof theDateObjVal}`);

    //判斷日期格式
    let sp = document.getElementById("datesp");


    if (isExistDate(theDateObjVal))
        sp.innerHTML = "<img src='image/correct.png'>日期正確";
    else
        sp.innerHTML = "<img src='image/error.png'>無此日期或格式錯誤";

    function isExistDate(theDateObjVal) {
        var dateObj = theDateObjVal.split('/'); // 日期為yyyy/mm/dd       
        var theYear = parseInt(dateObj[0]);
        var theMonth = parseInt(dateObj[1]);
        var theDay = parseInt(dateObj[2]);
        var isLeap = new Date(theYear, 1, 29).getDate() === 29; // 判斷閏年

        //列出12個月每月的最大日期
        var limitInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];


        if (isLeap) { // 若為閏年，最大日期限制改為 29
            limitInMonth[1] = 29;
        }

        // 比對該日是否超過每個月份最大日期限制
        return theDay <= limitInMonth[theMonth - 1];
    }

}