function checkName() {
    //取得idName元素
    let theNameObj = document.getElementById("idName");
    console.log(theNameObj);
    //取得idName元素值
    let theNameObjVal = theNameObj.value;
    console.log(theNameObjVal);
    console.log(`typeof=${typeof theNameObjVal}`);

    //判斷元素值是否為空白，長度是否大於2
    //如果長度大於2，判斷是否都是中文
    let sp = document.getElementById("namesp");
    let theNameObValLen = theNameObjVal.length;
    let flag1 = true;

    if (theNameObjVal == "")
        sp.innerHTML = "<img src='image/error.png'>不可空白";
    else if (theNameObValLen >= 2) {
        // sp.innerHTML = "ok >=2"                    
        for (let i = 0; i < theNameObValLen; i++) {
            let ch = theNameObjVal.charCodeAt(i);
            if (ch < 0x4e00 || ch > 0x9fff)
                flag1 = false;
            // if (flag1) break;
        }
        if (flag1)
            sp.innerHTML = "<img src='image/correct.png'>姓名格式正確";
        else
            sp.innerHTML = "<img src='image/error.png'>姓名請輸入中文";

    } else {
        sp.innerHTML = "<img src='image/error.png'>姓名至少兩個字以上";
    }
}

