function checkPwd() {
    //取得idPwd元素
    let thePwdObj = document.getElementById("idPwd");
    console.log(thePwdObj);
    //取得idPwd元素值
    let thePwdObjVal = thePwdObj.value;
    console.log(thePwdObjVal);
    console.log(`typeof=${typeof thePwdObjVal}`);

    //判斷元素值是否為空白，密碼長度是否大於6
    //如果長度是否大於6，判斷是否包含字母、數字、特殊符號
    let sp = document.getElementById("pwdsp");
    let thePwdObValLen = thePwdObjVal.length;
    let flag1 = false, flag2 = false, flag3 = false;

    if (thePwdObjVal == "")
        sp.innerHTML = "<img src='image/error.png'>不可空白";
    else if (thePwdObValLen >= 6) {
        // sp.innerHTML = "ok >=6"   

        for (let i = 0; i < thePwdObValLen; i++) {
            let ch = thePwdObjVal.charAt(i).toUpperCase();
            if (ch >= "A" && ch <= "Z")
                flag1 = true;
            if (flag1) break;
        }
        if (flag1) {
            for (let j = 0; j < thePwdObValLen; j++) {
                let ch = thePwdObjVal.charAt(j);
                if (ch >= 0 && ch <= 9)
                    flag2 = true;
                if (flag2) break;
            }
            if (flag2) {
                // sp.innerHTML = "correct";
                for (let k = 0; k < thePwdObValLen; k++) {
                    let ch = thePwdObjVal.charAt(k);
                    if (ch == "!" || ch == "@" || ch == "#" || ch == "$" 
                    || ch == "%" || ch == "^" || ch == "&" || ch == "*")
                        flag3 = true;
                    if (flag3) break;
                }
                if (flag3)
                    sp.innerHTML = "<img src='image/correct.png'>密碼格式正確";
                else
                    sp.innerHTML = "<img src='image/error.png'>密碼必須包含特殊字元"




            } else
                sp.innerHTML = "<img src='image/error.png'>密碼必須包含數字跟特殊字元";
        } else
            sp.innerHTML = "<img src='image/error.png'>密碼必須包含英文跟特殊字元";
    } else
        sp.innerHTML = "<img src='image/error.png'>密碼至少6個字以上";
}