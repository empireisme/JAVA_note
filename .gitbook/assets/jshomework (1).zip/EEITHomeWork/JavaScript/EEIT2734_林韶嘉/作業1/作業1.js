// 變數宣告
var i, j;

for (i = 2; i <= 9; i++) {
    document.write("<tr>");
    j = 1;
    while (j <= 9) {
        document.write("<td>");
        document.write(i + "*" + j + "=" + i * j);
        document.write("</td>");
        j++;
    }
    document.write("<tr>");
}