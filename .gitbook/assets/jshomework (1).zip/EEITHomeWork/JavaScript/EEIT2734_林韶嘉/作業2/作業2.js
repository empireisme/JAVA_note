function checkname(){   //取得name元素
    let thenameObj = document.getElementById("name");
    console.log(thenameObj);

    let thenameObjval = thenameObj.value;
    console.log(thenameObjval);
    console.log(typeof thenameObjval); //string
    let sp1 = document.getElementById("namesp");
    let thenameObjvallen = thenameObjval.length;
    let flag1 = false


    if (thenameObjval == "") {
    sp1.innerHTML = "請輸入姓名"
    } else if (thenameObjvallen >= 2) {
        for(i=0;i<thenameObjvallen;i++){  
        let ch = thenameObjval.charCodeAt(i)                         
    if(ch>=0x4e00 && ch<=0x9fff){
        flag1=true
            console.log(true)   
            if (flag1 == true)
            sp1.innerHTML = "輸入正確"; 
            }else{
            sp1.innerHTML="請輸入中文"
            console.log(false)  
            break;
          }
                  
    }
                               
    } else {
    sp1.innerHTML = "姓名長度需要大於2";
}
}




function checkPwd() {
    //取得idPwd元素
    let thepwdObj = document.getElementById("idPwd");
    console.log(thepwdObj);
    //取得idPwd元素值
    let thepwdObjval = thepwdObj.value;
    console.log(thepwdObjval);
    console.log(typeof thepwdObjval); //string

    //判斷元素值是否為空白，密碼長度是否大於6
    //如果長度是否大於6，判斷是否包含字母、數字、特殊符號
    let sp = document.getElementById("idsp");
    let thepwdObjvallen = thepwdObjval.length;
    let flag1 = false, flag2 = false, flag3 = false

    if (thepwdObjval == "") {
        sp.innerHTML = "請輸入密碼"
    } else if (thepwdObjvallen >= 6) {
        for (let i = 0; i < thepwdObjvallen; i++) {
            let ch = thepwdObjval.charAt(i).toUpperCase();
            if (ch >= "A" && ch <= "Z")
                flag1 = true;

            else if (ch >= "0" && ch <= "9")
                flag2 = true;

            else if (ch == "!" || ch == "@" || ch == "#" || ch == "$" || ch == "%" || ch == "^" || ch == "&" || ch == "*")
                flag3 = true;

            if (flag1 == true && flag2 == true && flag3 == true)
                break;

        } for (let i = 0; i < thepwdObjvallen; i++) {
            if (flag1 == true && flag2 == true && flag3 == true) {
                sp.innerHTML = "輸入正確";
            } else {
                sp.innerHTML = "不正確";
            }
        }
    } else {
        sp.innerHTML = "密碼長度需要大於6";
    }
}

function checkdate(){
    let thedateObj = document.getElementById("date1");
    let thedateObjVal = thedateObj.value;
    let sp = document.getElementById("datesp");
    if(!isDateExit(thedateObjVal))
        sp.innerHTML="無此日期"
    else
        sp.innerHTML="正確"
}
function isDateExit(thedateObjVal){
    let dateobj = thedateObjVal.split("/");
    let limitDate = [31,28,31,30,31,30,31,31,30,31,30,31];

    let theyear = parseInt(dateobj[0]);
    let themonth = parseInt(dateobj[1]);
    let thedate = parseInt(dateobj[2]);

    let isLeap = new Date(theyear,1,29).getDate()===29;

    if(isLeap){
        limitDate[1]=29;
    }
    return thedate <=limitDate[themonth-1]


}