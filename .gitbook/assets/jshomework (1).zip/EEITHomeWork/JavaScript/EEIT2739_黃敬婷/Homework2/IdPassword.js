// 這段是姓名
document.getElementById("idName").onblur = checkName;

function checkName() {
    //取得元素值
    let theNameObjVal = document.getElementById("idName").value;
    let re = /^.+[\u4e00-\u9fff]$/;

    let sp = document.getElementById("nameidsp");
    let theNameObjValLen = theNameObjVal.length;
    if (theNameObjVal == "")
        sp.innerHTML = "<img src='PNG/error.png'>請輸入姓名";
    else if (theNameObjValLen >= 2) {
        if (re.test(theNameObjVal))
            sp.innerHTML = "<img src='PNG/correct.png'>正確";
        else
            sp.innerHTML = "<img src='PNG/error.png'>姓名必須是中文";
    } else {
        sp.innerHTML = "<img src='PNG/error.png'>姓名至少2個字"
    }

}

// 這裡開始是密碼
document.getElementById("idPwd").onblur = checkPwd;

function checkPwd() {
    //取得idPwd元素
    let thePwdObj = document.getElementById("idPwd");
    console.log(thePwdObj);
    //取得idPwd元素值
    let thePwdObjVal = thePwdObj.value;
    console.log(thePwdObjVal);
    console.log(typeof thePwdObjVal);

    //判斷元素值是否為空白，密碼長度是否大於6
    //如果長度是否大於6，判斷是否包含字母、數字、特殊符號
    let sp = document.getElementById("idsp");
    let thePwdObjValLen = thePwdObjVal.length;
    let flag1 = false,
        flag2 = false,
        flag3 = false;

    if (thePwdObjVal == "")
        sp.innerHTML = "<img src='PNG/error.png'>請輸入密碼";
    else if (thePwdObjValLen >= 6) {
        // sp.innerHTML=">=6";
        for (let i = 0; i < thePwdObjValLen; i++) {
            let ch = thePwdObjVal.charAt(i).toUpperCase();
            if (ch >= "A" && ch <= "Z")
                flag1 = true;
            else if (ch >= "0" && ch <= "9")
                flag2 = true;
            if (flag1 && flag2) break;
        }
        if (flag1 && flag2)
            sp.innerHTML = "<img src='PNG/correct.png'>正確";
        else
            sp.innerHTML = "<img src='PNG/error.png'>密碼必須包含英文、數字、特殊字元[!@#$%^&*]";
    } else {
        sp.innerHTML = "<img src='PNG/error.png'>密碼長度至少6個字";
    }
}

// 這裡開始是生日
document.getElementById("idDate").onblur = isExistDate;

function isExistDate(dateStr) {
    let theDateObj = document.getElementById("idDate");
    let theDateObjVal = theDateObj.value;
    let sp = document.getElementById("datesp")

    if (!isDateExit(theDateObjVal))
        sp.innerHTML = "<img src='PNG/error.png'>日期輸入錯誤";
    else
        sp.innerHTML = "<img src='PNG/correct.png'>正確";
}

function isDateExit(theDateObjVal) {
    let dateObj = theDateObjVal.split('/');

    let limitDate = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    let theYear = parseInt(dateObj[0]);
    let theMonth = parseInt(dateObj[1]);
    let theDate = parseInt(dateObj[2]);

    let isLeap = new Date(theYear, 1, 29).getDate() === 29; //判斷是否閏年
    if (isLeap) {
        limitDate[1] = 29;
    }
    return theDate <= limitDate[theMonth - 1];
}