document.write("<table>");
document.write("<caption>九九乘法表</caption>");

for (j = 1; j <= 9; j++) {
    document.write("<td >");
    for (i = 2; i <= 9; i++) {
        sum = i * j;
        document.write(i + "*" + j + "=" + sum + "<br>");
    }
    document.write("</td>");
}
document.write("</table>");