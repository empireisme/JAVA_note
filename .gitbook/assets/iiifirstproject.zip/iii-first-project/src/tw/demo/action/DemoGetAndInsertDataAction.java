package tw.demo.action;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import tw.demo.model.AqiDataDaoImpl;
import tw.demo.util.DbInfoUtil;

public class DemoGetAndInsertDataAction {

	public static void main(String[] args)
			throws IOException, NumberFormatException, SQLException, ClassNotFoundException {
		DemoGetAndInsertDataAction action1 = new DemoGetAndInsertDataAction();
		ArrayList<String> listAQI = action1.getURLContent();

		// 先展示拿到一行資料的逗點間的資料
//		String[] tokens = listAQI.get(5).split(",");
//		
//		System.out.println("=====一筆資料===================");
//        // 拿到 站名, AQI, 空氣品質, PM2.5
//		System.out.println("站名: " + tokens[0]); // 基隆
//		System.out.println("AQI: " + tokens[2]); 
//		System.out.println("空氣品質:  " + tokens[4]);
//		System.out.println("PM 2.5: " + tokens[11]);
//		System.out.println("========================");
		
		// 開啟資料庫連線，準備放入資料
		Connection conn = DbInfoUtil.createSQLServerConn();

		AqiDataDaoImpl theDao = new AqiDataDaoImpl(conn);

		for (int i = 0; i < listAQI.size(); i++) {
			String[] tokens = listAQI.get(i).split(",");

			if (tokens[2].equals("")) {
				tokens[2] = "999";
			}

			if (tokens[11].equals("")) {
				tokens[11] = "999";
			}

			System.out.println("正要輸入: " + tokens[0] + tokens[2] + tokens[4] + tokens[11]);

			theDao.insertData(tokens[0], Integer.parseInt(tokens[2]), tokens[4], Integer.parseInt(tokens[11]));
		}

		System.out.println("成功輸入完畢，關閉連線");

		DbInfoUtil.closeConnection();

	}

	private ArrayList<String> getURLContent() throws IOException {
		String sourceUrl = "https://data.epa.gov.tw/api/v1/aqx_p_432?limit=1000&api_key=9be7b239-557b-4c10-9775-78cadfc555e9&format=csv";
		

		URL url = new URL(sourceUrl);
		URLConnection conn = url.openConnection();
		InputStreamReader inputReader = new InputStreamReader(conn.getInputStream(), "UTF-8");
		BufferedReader bReader = new BufferedReader(inputReader);

		ArrayList<String> listAQI = new ArrayList<String>();
		try {

			String content = "";

			// 看資料
			while (bReader.ready()) {
				content = bReader.readLine();
//					System.out.println(content);
				listAQI.add(content); // 加到 list 裡面
			}

			// 刪除第一筆
			listAQI.remove(0);

			System.out.println("清理完第一筆後: ");
			for (String oneRow : listAQI) {
				System.out.println("oneRow: " + oneRow);
			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} finally {
			bReader.close();
			inputReader.close();
		}
		return listAQI;
	}

}
