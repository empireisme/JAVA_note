package tw.demo.action;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import tw.demo.model.AqiDataDaoImpl;
import tw.demo.util.DbInfoUtil;

public class DemoReadAllDataAction {

	public static void main(String[] args) throws SQLException, ClassNotFoundException, IOException {

		Connection conn = DbInfoUtil.createSQLServerConn();
		AqiDataDaoImpl dao = new AqiDataDaoImpl(conn);
		
		dao.readAllData();
		DbInfoUtil.closeConnection();

	}

}
