package tw.demo.model;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AqiDataDaoImpl implements AqiDataDao {

	private Connection conn;

	public AqiDataDaoImpl(Connection conn2) {
		this.conn = conn2;
	}

	@SuppressWarnings("null")
	@Override
	public void readAllData() throws SQLException, IOException {
		String sqlStr = "Select * from AqiData";
		PreparedStatement preState = conn.prepareStatement(sqlStr);
		ResultSet rs = preState.executeQuery();

		while(rs.next()) {
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3) + " " + rs.getString(4)
			 + " " + rs.getInt(5)   );
		}

		rs.close();
		preState.close();

	}

	@Override
	public void insertData(String siteName, Integer aqi, String airStatus, Integer pm25) throws SQLException {
		String sqlStr = "Insert into AqiData(sitename, aqi, airStatus, pm25) Values(?,?,?,?)";
		PreparedStatement preState = conn.prepareStatement(sqlStr);
		preState.setString(1, siteName);
		preState.setInt(2, aqi);
		preState.setString(3, airStatus);
		preState.setInt(4, pm25);
		preState.execute();
		preState.close();

	}

	@Override
	public void writeAllData() throws SQLException, IOException {
		String sqlStr = "Select * from AqiData";
		PreparedStatement preState = conn.prepareStatement(sqlStr);
		ResultSet rs = preState.executeQuery();

		// 檢查有無資料
//		while(rs.next()) {
//			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3) + " " + rs.getString(4)
//			 + " " + rs.getInt(5)   );
//		}
		
		// 這個就可以，指定編碼要用下方
//		BufferedWriter bWriter= new BufferedWriter(new FileWriter("C:\\javaOutPut\\firstProject.csv"));
		
		// 指定編碼
		BufferedWriter bWriter = new BufferedWriter
			    (new OutputStreamWriter(new FileOutputStream("C:\\javaOutPut\\firstProject.csv"), "UTF-8"));
		

		bWriter.write("id, 站址, aqi, 空氣品質, pm2.5");
		bWriter.newLine();
		
		// 必須先關閉上方檢查有無資料
		while(rs.next()) {
			Integer id = rs.getInt(1);
			String siteName = rs.getString(2);
			Integer aqi = rs.getInt(3);
			String airStatus = rs.getString(4);
			Integer pm25 = rs.getInt(5);
			bWriter.write(id+","+siteName+","+aqi+","+airStatus+","+pm25);
			bWriter.newLine();
		}
		

		bWriter.close();
		rs.close();
		preState.close();
		
	}

}
