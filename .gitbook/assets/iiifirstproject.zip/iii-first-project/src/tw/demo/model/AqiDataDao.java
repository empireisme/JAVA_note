package tw.demo.model;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public interface AqiDataDao {
	
	public void insertData(String siteName, Integer aqi, String airStatus, Integer pm25) throws SQLException;

	public void readAllData() throws SQLException, IOException;
	public void writeAllData() throws SQLException, IOException;
}
