package tw.demo.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbInfoUtil {

	private static Connection conn;
	
	public static Connection createSQLServerConn() throws SQLException, ClassNotFoundException{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=iiiFirstProject;user=kirito;password=c8763";
		conn = DriverManager.getConnection(urlStr);
		return conn;
	}
	
	public static void closeConnection() throws SQLException {
		if(conn!=null) {
			conn.close();
		}
	}
}
