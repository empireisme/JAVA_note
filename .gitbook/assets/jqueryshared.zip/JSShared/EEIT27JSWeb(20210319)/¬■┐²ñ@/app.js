
   function f() {

       for (i=0;i<=100;i++) {}

   }

   let i=10;

   f();

   console.log("i="+i);

